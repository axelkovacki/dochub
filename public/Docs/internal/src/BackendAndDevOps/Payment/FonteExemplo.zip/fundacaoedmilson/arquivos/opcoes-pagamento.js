var url = "https://"+(window.location.href.indexOf('hmg')>0 ? "hmg." : 'app.')+"smartbill.com.br/proxy";
var urlCep = "https://"+(window.location.href.indexOf('hmg')>0 ? "hmg." : 'app.')+"smartbill.com.br/cep/";
var gerente = "d7ebff4c-4e5a-4e71-a385-5bc4dd1d5fbc";

$(document).ready(function () {

    $("#cidadeSelecionada").attr("value", "Taquaritinga");

    var param = location.href.split('?')[1].toString();
    $("#uuidPlano").attr("value", param.substring(0,36));

    if(param.length>36) {
        $("#valorInformado").attr("value", param.substring(36));
    }

    $.ajax({
        type: "POST",
        url: url + "/checkout/obter/plano?" + gerente,
        data: {uuidPlano: $("#uuidPlano").val()},
        dataType: 'json',
        success: function (data) {
            if (data) {
                if (data.status == 'success') {
                    $("#nomePlano").text(data.data.plano.nome);
                    $("#descricaoPlano").text(data.data.plano.descricao.replace("#",$("#valorInformado").val()));
                    $("#uuidCicloFaturamento").attr('value', data.data.plano.ciclosFaturamento[0].uuid);
                    $("#uuidMeioPagamento").attr('value', data.data.plano.meiosPagamento[0].uuid);
                    $("body").fadeIn(300);
                    $("#uf").change();
                    $("#form").data('bootstrapValidator').resetForm();
                } else {
                    bootbox.alert('Erro ao obter plano!');
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
            bootbox.alert("Servidor fora do ar. Entre em contato com o suporte do Smartbill!");
        }
    });

    $('#form').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            cpf: {
                validators: {
                    regexp: {
                        regexp: /^\d{3}\.?\d{3}\.?\d{3}\-?\d{2}$/,
                        message: 'CPF inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }
            },
            cc: {
                validators: {
                    creditCard: {
                        message: 'Nº do Cartão de Crédito inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }
            },
            cvv: {
                validators: {
                    cvv: {
                        creditCardField: 'cc',
                        message: 'Código de segurança inválido'
                    }
                }
            },
            dv: {
                validators: {
                    regexp: {
                        regexp: /^(1[0-2]|0[1-9]|\d)\/(20\d{2}|19\d{2}|0(?!0)\d|[1-9]\d)$/,
                        message: 'Data de validade incorreta'
                    }
                }
            },
            nome: {
                validators: {
                    regexp: {
                        regexp: /^[a-z\s]+$/i,
                        message: 'Nome inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }
            },
            email: {
                validators: {
                    emailAddress: {
                        message: 'E-mail inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }
            },
            cep: {
                validators: {
                    regexp: {
                        regexp: /^\d{2}\.?\d{3}\-?\d{3}$/,
                        message: 'CEP inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }
            },
            endereco: {
                validators: {
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }

            },
            numero: {
                validators: {
                    regexp: {
                        regexp: /^[\d\-]+$/,
                        message: 'Telefone inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }
            },
            bairro: {
                validators: {
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }

            },
            uf: {
                validators: {
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }

            },
            dddCel: {
                validators: {
                    regexp: {
                        regexp: /^[\d]{2}$/,
                        message: 'DDD inválido'
                    }
                }
            },
            dddTel: {
                validators: {
                    regexp: {
                        regexp: /^\d{2}$/,
                        message: 'DDD inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }
            },
            cel: {
                validators: {
                    regexp: {
                        regexp: /^[\d\-]+$/,
                        message: 'Celular inválido'
                    }
                }

            },
            tel: {
                validators: {
                    regexp: {
                        regexp: /^[\d\-]+$/,
                        message: 'Telefone inválido'
                    },
                    notEmpty: {
                        message: 'Campo é obrigatório'
                    }
                }

            }
        }
    })
        .on('success.form.bv', function (e) {
            e.preventDefault();

            var cliente = {
                orgaoPublico: false,
                razaoSocial: $("#nome").val(),
                nomeFantasia: $("#nome").val(),
                cnpjCpf: $("#cpf").val(),
                telefoneDdd: $("#dddTel").val(),
                telefoneNumero: $("#tel").val(),
                emailGeral: $("#email").val(),
                contato: {
                    nome: $("#nome").val(),
                    cpf: $("#cpf").val(),
                    email: $("#email").val(),
                    telefoneDdd: $("#dddTel").val(),
                    telefoneNumero: $("#tel").val(),
                    celularDdd: $("#dddCel").val(),
                    celularNumero: $("#cel").val()
                },
                endereco: {
                    logradouro: $("#endereco").val(),
                    numero: $("#numero").val(),
                    complemento: $("#complemento").val(),
                    bairro: $("#bairro").val(),
                    cep: $("#cep").val(),
                    uf: $("#uf").val(),
                    cidade: $("#cidade").val()
                }
            };

            $("#button-cadastro").attr('value', 'Processando...');

            var tipoBandeira = "";

            if ($("#visaValue").is(":checked")) {
                tipoBandeira = $("#visaValue").val();
            } else {
                if ($("#masterValue").is(":checked")) {
                    tipoBandeira = $("#masterValue").val();
                } else {
                    if ($("#hiperValue").is(":checked")) {
                        tipoBandeira = $("#hiperValue").val();
                    } else {
                        if ($("#amexValue").is(":checked")) {
                            tipoBandeira = $("#amexValue").val();
                        } else {
                            if ($("#dinersValue").is(":checked")) {
                                tipoBandeira = $("#dinersValue").val();
                            } else {
                                if ($("#eloValue").is(":checked")) {
                                    tipoBandeira = $("#eloValue").val();
                                } else {
                                    bootbox.alert('Você não selecionou a bandeira do cartão de crédito!');
                                    $("#button-cadastro").attr('value', 'Confirmar');
                                    return;
                                }
                            }
                        }
                    }
                }
            }

            $.ajax({
                type: "POST",
                url: url + "/checkout/clientes?" + gerente,
                data: cliente,
                dataType: "json",
                success: function (data) {

                    if (data.status == 'success') {

                        var contratar = {
                            uuidPlano: $("#uuidPlano").val(),
                            uuidCliente: data.data.uuidCliente,
                            uuidCicloFaturamento: $("#uuidCicloFaturamento").val(),
                            uuidMeioPagamento: $("#uuidMeioPagamento").val(),
                            valorPedido: $("#valorInformado").val(),
                            cartao: {
                                ano: $("#ano").val(),
                                mes: $("#mm").val(),
                                numero: $("#cc").val(),
                                security: $("#cvv").val(),
                                tipoBandeira: tipoBandeira,
                                titular: $("#nomeCC").val()
                            }
                        }

                        $.ajax({
                            type: "POST",
                            url: url + "/checkout/contratar?" + gerente,
                            data: contratar,
                            dataType: "json",
                            success: function (data) {
                                if (data.status == 'success') {
                                    bootbox.alert(data.message);
                                    var url = "confirmacao-de-doacao.html?" + contratar.uuidCliente;
                                    window.location = url;
                                } else {
                                    bootbox.alert(data.message);
                                }
                            },
                            error: function (err) {
                                bootbox.alert(err);
                            }
                        });
                    } else {
                        bootbox.alert("Erro interno. Entre em contato com o suporte técnico do Smartbill!");
                    }
                },
                error: function (err) {
                    bootbox.alert(err);
                }
            });

            $("#button-cadastro").attr('value', 'Confirmar');
        });
});

$("#cep").change(function () {

    if ($("#cep").val() != '') {
        $.ajax({
            type: "GET",
            url: urlCep + $("#cep").val() + ".json",
            success: function (data) {
                if (data.status == 1) {
                    $("#bairro").attr("value", data.district);
                    $("#uf").val(data.state);
                    $("#cidade").attr("value", data.city);
                    $("#endereco").attr("value", data.address);
                    $("#cidadeSelecionada").attr("value", data.city);
                    $("#uf").change();
                    $("#form").data('bootstrapValidator').resetForm();
                } else {
                    bootbox.alert("CEP não encontrado, preencha manualmente!");
                }
            }
        });
    }
});

$("#uf").change(function () {

    $.ajax({
        type: "POST",
        url: url + "/checkout/obter/cidade?" + gerente,
        data: {uf: $("#uf").val()},
        dataType: 'json',
        success: function (data) {
            if (data.status == 'success') {
                $("#cidade").html('');
                var k = 0;
                while (k < data.data.cidades.length) {
                    $("#cidade").append("<option value=\"" + data.data.cidades[k] + "\">" + data.data.cidades[k] + "</option>");
                    k++;
                }
                if ($("#cidadeSelecionada").val() != "") {
                    $("#cidade").val($("#cidadeSelecionada").val());
                    $("#cidadeSelecionada").attr("value", "");
                }
            }
        }
    });
});

$("#cpf").change(function () {
    $.ajax({
        type: "POST",
        url: url + "/checkout/obter/clientePorCpf?" + gerente,
        data: {cnpjCpf: $("#cpf").val()},
        dataType: 'json',
        success: function (data) {
            if (data) {
                if (data.status == 'success') {
                    bootbox.dialog({
                        message: "Este cliente já possui planos. Verifique para continuar sem duplicidade. Deseja continuar?",
                        title: "Alerta",
                        buttons: {
                            main: {
                                label: "Continuar",
                                className: "btn-primary",
                                callback: function () {
                                    $("#titular").attr("value", data.data.clientes[0].razaoSocial);
                                    $("#nomeCC").attr("value", data.data.clientes[0].razaoSocial);
                                    $("#nome").attr("value", data.data.clientes[0].razaoSocial);
                                    $("#dddTel").attr("value", data.data.clientes[0].telefoneDdd);
                                    $("#tel").attr("value", data.data.clientes[0].telefoneNumero);
                                    $("#email").attr("value", data.data.clientes[0].emailGeral);
                                    $("#dddCel").attr("value", data.data.clientes[0].contato.celularDdd);
                                    $("#cel").attr("value", data.data.clientes[0].contato.celularNumero);
                                    $("#endereco").attr("value", data.data.clientes[0].endereco.logradouro);
                                    $("#numero").attr("value", data.data.clientes[0].endereco.numero);
                                    $("#complemento").attr("value", data.data.clientes[0].endereco.complemento);
                                    $("#bairro").attr("value", data.data.clientes[0].endereco.bairro);
                                    $("#cep").attr("value", data.data.clientes[0].endereco.cep);
                                    $("#uf").val(data.data.clientes[0].endereco.uf);
                                    $("#uf option").each(function () {
                                        if ($(this).text() == data.data.clientes[0].endereco.uf) {
                                            $(this).attr("selected", true);
                                        } else {
                                            $(this).removeAttr("selected");
                                        }
                                    });
                                    $("#cidadeSelecionada").attr("value", data.data.clientes[0].endereco.cidade);
                                    $("#uf").change();
                                    $("#form").data('bootstrapValidator').resetForm();
                                }
                            },
                            danger: {
                                label: "Não",
                                className: "btn-danger",
                                callback: function () {
                                }
                            }
                        }
                    });
                } else {
                    $("#titular").attr("value", "");
                    $("#nomeCC").attr("value", "");
                    $("#nome").attr("value", "");
                    $("#dddTel").attr("value", "");
                    $("#tel").attr("value", "");
                    $("#email").attr("value", "");
                    $("#dddCel").attr("value", "");
                    $("#cel").attr("value", "");
                    $("#endereco").attr("value", "");
                    $("#numero").attr("value", "");
                    $("#complemento").attr("value", "");
                    $("#bairro").attr("value", "");
                    $("#cep").attr("value", "");
                    $("#uf").val("SP");
                    $("#cidadeSelecionada").attr("value", "Taquaritinga");
                    $("#uf").change();

                }
            }
        }
    });
});

$("#nome").change(function () {
    $("#nomeCC").attr('value', $("#nome").val());
    $("#titular").attr('value', $("#nome").val());
});

$("#cartaoValue").change(function () {
    $("#tipos").addClass('hidden');
    $("#cartaoInput").removeClass('hidden');
    $("#contaInput").addClass('hidden');
});

$("#debitoValue").change(function () {
    $("#tipos").removeClass('hidden');
    $("#cartaoInput").addClass('hidden');
});

$("#boletoValue").change(function () {
    $("#tipos").removeClass('hidden');
    $("#cartaoInput").addClass('hidden');
});

