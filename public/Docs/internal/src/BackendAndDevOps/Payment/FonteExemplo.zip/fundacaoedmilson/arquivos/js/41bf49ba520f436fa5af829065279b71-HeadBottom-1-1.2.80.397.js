/*! VTEX Commerce Suite Generated */
/*! 
 * inlinescript
 */
function addSeparators(n, t) {
    for (var u = 0, r = n, i = ""; r > 999;)u = r % 1e3, r = (r - u) / 1e3, i = i + u.padLeft(3), r > 0 && (i = t + i);
    return r > 0 && (i = r.toFixed(0) + i), i == "" ? "0" : i
}
function GetCartAddLink(n, t, i, r) {
    if (n > 0 && i > 0) {
        var u = "";
        jscheckoutGiftListId != "undefined" && jscheckoutGiftListId != "" && (u = "&gr=" + jscheckoutGiftListId);
        checkoutUrl = jscheckoutAddUrl + "/?sku=" + n + "&seller=" + t + "&qty=" + i + "&sc=" + r + u + "&aaa"
    }
    return checkoutUrl
}
var defaultUtmFromFolder = "", ___scriptPath, ___scriptPathTransac, Class, Namespace;
/*! 
 * inlinescript
 */
vtxctx = {searchTerm: "politica-privacidade", isOrder: "0", isCheck: "0", isCart: "0", actionType: "", actionValue: "", login: "", url: "doe.fundacaoedmilson.org.br", transurl: "doe.fundacaoedmilson.org.br"};
/*! 
 * inlinescript
 */
___scriptPath = "";
/*! 
 * inlinescript
 */
___scriptPathTransac = "";
/*! 
 * inlinescript
 */
var jscheckoutUrl = "https://doe.fundacaoedmilson.org.br/checkout/#/cart", jscheckoutAddUrl = "https://doe.fundacaoedmilson.org.br/checkout/cart/add", jscheckoutGiftListId = "", jsnomeSite = "fundacaoedmilson", jsnomeLoja = "fundacaoedmilson", jssalesChannel = "1", defaultStoreCurrency = "R$", localeInfo = {CountryCode: "BRA", CultureCode: "pt-BR", CurrencyLocale: {RegionDisplayName: "Brazil", RegionName: "BR", RegionNativeName: "Brasil", TwoLetterIsoRegionName: "BR", CurrencyEnglishName: "Real", CurrencyNativeName: "Real", CurrencySymbol: "R$", ISOCurrencySymbol: "BRL", Locale: 1046, Format: {CurrencyDecimalDigits: 2, CurrencyDecimalSeparator: ",", CurrencyGroupSeparator: ".", CurrencyGroupSize: 3, StartsWithCurrencySymbol: !0}, FlagUrl: "https://www.geonames.org/flags/x/br.gif"}};
/*! 
 * inlinescript
 */
(function () {
    var n, t;
    try {
        n = document.createElement("script");
        n.type = "text/javascript";
        n.async = !0;
        n.src = "//dmx56ht1p4edz.cloudfront.net/rc.js?an=fundacaoedmilson";
        n.target = "_blank";
        t = document.getElementsByTagName("script")[0];
        t.parentNode.insertBefore(n, t)
    } catch (i) {
    }
})();
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.ajax.wait.js
 */
$(document).ready(function () {
    var n = $("meta[name=language]").attr("content");
    n === "es-AR" ? $("body").prepend('<div id="ajaxBusy" class="load loading"><p>Cargando datos...<\/p><\/div>') : $("body").prepend('<div id="ajaxBusy" class="load loading"><p>Aguarde...<\/p><\/div>')
});
$(document).ajaxStart(function () {
    $("#ajaxBusy").show()
}).ajaxStop(function () {
    $("#ajaxBusy").hide()
});
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.common.js
 */
Class = {create: function () {
    return function () {
        this.initialize.apply(this, arguments)
    }
}};
Namespace = {create: function (n) {
    for (var i = !1, t = "", u = n.split("."), r = 0; r < u.length; r++)t != "" && (t += "."), t += u[r], i = this.exists(t), i || this.add(t);
    if (i)throw"Namespace: " + n + " is already defined.";
}, add: function (cob) {
    eval("window." + cob + " = new Object();")
}, exists: function (cob) {
    return eval("var NE = false; try{if(" + cob + "){NE = true;}else{NE = false;}}catch(err){NE=false;}"), NE
}};
Array.prototype.contains = function (n) {
    for (i = 0; i < this.length; i++)if (this[i] == n)return!0;
    return!1
};
Array.prototype.add = function (n) {
    this.unshift(n);
    $.unique(this)
};
Array.prototype.remove = function (n) {
    for (var i = !1, t = 0; t < this.length && !i;)this[t] == n && (this.splice(t, 1), i = !0), t++
};
String.prototype.format = function () {
    var n = arguments, i = typeof n[0] == "object", t;
    return i ? (t = n[0], this.replace(/{(\w+)}/g, function (n, i) {
        return typeof t[i] != "undefined" ? t[i] : n
    })) : this.replace(/{(\d+)}/g, function (t, i) {
        return typeof n[i] != "undefined" ? n[i] : t
    })
};
$.fn.serializeObject = function () {
    var n = {}, t = this.serializeArray();
    return $.each(t, function () {
        n[this.name] !== undefined ? (n[this.name].push || (n[this.name] = [n[this.name]]), n[this.name].push(this.value || "")) : n[this.name] = this.value || ""
    }), n
};
Number.prototype.padLeft = function (n) {
    for (var t = this.toFixed(0), i = n - t.length, r = ""; i > 0;)r += "0", i--;
    return r + t
};
Number.prototype.toBrazilianCurrency = function () {
    var n = this.toFixed(2), t = parseInt(n.split(".")[1]), i = parseInt(n.split(".")[0]), r = addSeparators(i, ".");
    return"R$ " + r + "," + t.padLeft(2)
}