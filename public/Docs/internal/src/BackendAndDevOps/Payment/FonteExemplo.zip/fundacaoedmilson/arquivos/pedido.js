var url = "https://"+(window.location.href.indexOf('hmg')>0 ? "hmg." : 'app.')+"smartbill.com.br/proxy";
var gerente = "d7ebff4c-4e5a-4e71-a385-5bc4dd1d5fbc";

var uuidCliente = location.href.split('?')[1];

$(document).ready(function() {

    $.ajax({
        type: "POST",
        url: url + "/checkout/contratos?" + gerente,
        data: {uuidCliente: uuidCliente},
        dataType: 'json',
        success: function (data) {
            if (data.status == 'success') {
                var contratos = data.data.contratos;

                var i=0;
                while(i<contratos.length){

                    var dataInicioVigencia = new Date(contratos[i].dataVigenciaInicio);
                    var dataFimVigencia = new Date(contratos[i].dataVigenciaFim);
                    var dataPrimeiroVenc = new Date(contratos[i].dataPrimeiroVencimento);

                    var periodo = "";
                    var valor = 0;

                    if(contratos[i].tipoPeriodicidade == 'ANUAL'){
                        periodo = contratos[i].quantidadeTipoVigencia/12;
                        valor = contratos[i].servico.valor;
                    }else{
                        periodo = contratos[i].quantidadeTipoVigencia;
                        valor = contratos[i].valor;
                    }
                    if(i==contratos.length-1){
                        $("#pedidos").append($('<tr>')
                                .append(
                                $('<td class="descricoes">').append('<b>Código:</b> <span class="textspan">'+contratos[i].codigoConsolidaFatura+'</span>'),
                                $('<td class="descricoes">').append('<b>Tipo:</b> <span class="textspan">'+contratos[i].servico.nome+'</span>'),
                                $('<td class="descricoes">').append('<b>Início vigência:</b> <span class="textspan">'+dataInicioVigencia.getDate()+'/'+(dataInicioVigencia.getMonth()+1)+'/'+dataInicioVigencia.getFullYear()+'</span>'),
                                $('<td class="descricoes">').append('<b>Fim vigência:</b> <span class="textspan">'+dataFimVigencia.getDate()+'/'+(dataFimVigencia.getMonth()+1)+'/'+dataFimVigencia.getFullYear()+'</span>'),
                                $('<td class="descricoes">').append('<b>Primeiro vencimento:</b> <span class="textspan">'+dataPrimeiroVenc.getDate()+'/'+(dataPrimeiroVenc.getMonth()+1)+'/'+dataPrimeiroVenc.getFullYear()+'</span>'),
                                $('<td class="descricoes">').append('<b>Periodicidade:</b> <span class="textspan">'+contratos[i].tipoPeriodicidade+'</span>'),
                                $('<td class="descricoes">').append('<b>Período:</b> <span class="textspan">'+periodo+'</span>'),
                                $('<td class="descricoes">').append('<b>Valor:</b> <span class="textspan valor">'+valor.toFixed(2)+'</span>')
                            )
                        );
                        $('.valor').priceFormat({
                            prefix: 'R$ ',
                            centsSeparator: ',',
                            thousandsSeparator: '.'
                        });
                    }
                    i++;
                }
                $("body").fadeIn(500);
            }

        }
    });

    $.ajax({
        type: "POST",
        url: url + "/checkout/obter/clientePorUuid?" + gerente,
        data: {uuid: uuidCliente},
        dataType: 'json',
        success: function (data) {
            if (data.status == 'success') {
                $("#cpf").append("<b>CPF:</b> "+data.data.cliente.cnpjCpf);
                $("#nome").append("<b>Nome:</b> "+data.data.cliente.razaoSocial);
                $("#email").append("<b>Email:</b> "+data.data.cliente.emailGeral);
                $("#dddTel").append("<b>DDD:</b> "+data.data.cliente.telefoneDdd);
                $("#tel").append("<b>Telefone:</b> "+data.data.cliente.telefoneNumero);
                $("#dddCel").append("<b>DDD:</b> "+data.data.cliente.contato.celularDdd);
                $("#cel").append("<b>Celular:</b> "+data.data.cliente.contato.celularNumero);
                $("#endereco").append("<b>Endereço:</b> "+data.data.cliente.endereco.logradouro);
                $("#numero").append("<b>Nº:</b> "+data.data.cliente.endereco.numero);
                $("#complemento").append("<b>Complemento:</b> "+data.data.cliente.endereco.complemento);
                $("#bairro").append("<b>Bairro:</b> "+data.data.cliente.endereco.bairro);
                $("#cep").append("<b>CEP:</b> "+data.data.cliente.endereco.cep);
                $("#uf").append("<b>UF:</b> "+data.data.cliente.endereco.uf);
                $("#cidade").append("<b>Cidade:</b> "+data.data.cliente.endereco.cidade);
            } else {
                alert('Cliente não encontrado!')
            }
        }
    });
});
