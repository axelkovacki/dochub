$(document).ready(function() {
    var options = $("#ano");
    var anoCorrente = new Date().getFullYear();
    var anos = [];
    for (var i = anoCorrente; i <= (anoCorrente+10); i++) {
        anos.push(i);
    }
    $.each(anos, function(i, ano) {
        options.append($("<option />").val(ano).text(ano));
    });
});


