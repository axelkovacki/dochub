/*! VTEX Commerce Suite Generated */
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/Track.js
 */
function TrackCall(n) {
    var t = location.search, i;
    t.indexOf("utm_source") < 0 && window.defaultUtmFromFolder != "" && (t = "?" + window.defaultUtmFromFolder);
    t == "" ? t = "?" : t += "&";
    i = escape(document.referrer).replace(/\//g, "%2F");
    t += "referrer=" + i;
    $.get(n + t)
}
function tb_init(n) {
    $(n).unbind("click").click(function () {
        var n = this.title || this.name || null, t = this.href || this.alt, i = this.rel || !1;
        return tb_show(n, t, i), this.blur(), !1
    })
}
function tb_show(n, t, i) {
    var e, f, u, s, o, r;
    try {
        if (n == null && t == "" && !i)return;
        if (typeof document.body.style.maxHeight == "undefined" ? ($("body", "html").css({height: "100%", width: "100%"}), $("html").css("overflow", "hidden"), document.getElementById("TB_HideSelect") === null && ($("body").append("<iframe id='TB_HideSelect'><\/iframe><div id='TB_overlay' style='position:fixed;z-index:10000;top:0px;left:0px;height:100%;width:100%'><\/div><div id='TB_window' style='position:fixed;z-index:10002;display:none;top:50%;left:50%'><\/div>"), $("#TB_overlay").click(tb_remove))) : document.getElementById("TB_overlay") === null && ($("body").append("<div id='TB_overlay' style='position:fixed;z-index:10000;top:0px;left:0px;height:100%;width:100%'><\/div><div id='TB_window' style='position:fixed;z-index:10002;display:none;top:50%;left:50%'><\/div>"), $("#TB_overlay").click(tb_remove)), n === null && (n = ""), $("body").append("<div id='TB_load' style='position:fixed;display:none;z-index:10003'><\/div>"), $("#TB_load").show(), e = t.indexOf("?") !== -1 ? t.substr(0, t.indexOf("?")) : t, f = /\.jpg$|\.jpeg$|\.png$|\.gif$|\.bmp$/, u = e.toLowerCase().match(f), u == ".jpg" || u == ".jpeg" || u == ".png" || u == ".gif" || u == ".bmp") {
            if (TB_PrevCaption = "", TB_PrevURL = "", TB_PrevHTML = "", TB_NextCaption = "", TB_NextURL = "", TB_NextHTML = "", TB_imageCount = "", TB_FoundURL = !1, i)for (TB_TempArray = $("a[@rel=" + i + "]").get(), TB_Counter = 0; TB_Counter < TB_TempArray.length && TB_NextHTML === ""; TB_Counter++)s = TB_TempArray[TB_Counter].href.toLowerCase().match(f), TB_TempArray[TB_Counter].href == t ? (TB_FoundURL = !0, TB_imageCount = "Image " + (TB_Counter + 1) + " of " + TB_TempArray.length) : TB_FoundURL ? (TB_NextCaption = TB_TempArray[TB_Counter].title, TB_NextURL = TB_TempArray[TB_Counter].href, TB_NextHTML = "<span id='TB_next'>&nbsp;&nbsp;<a href='#'>Next &gt;<\/a><\/span>") : (TB_PrevCaption = TB_TempArray[TB_Counter].title, TB_PrevURL = TB_TempArray[TB_Counter].href, TB_PrevHTML = "<span id='TB_prev'>&nbsp;&nbsp;<a href='#'>&lt; Prev<\/a><\/span>");
            imgPreloader = new Image;
            imgPreloader.onload = function () {
                imgPreloader.onload = null;
                var o = tb_getPageSize(), f = o[0] - 150, e = o[1] - 150, r = imgPreloader.width, u = imgPreloader.height;
                if (r > f ? (u = u * (f / r), r = f, u > e && (r = r * (e / u), u = e)) : u > e && (r = r * (e / u), u = e, r > f && (u = u * (f / r), r = f)), TB_WIDTH = r + 30, TB_HEIGHT = u + 60, $("#TB_window").append("<a href='' id='TB_ImageOff' title='Close'><img id='TB_Image' src='" + t + "' width='" + r + "' height='" + u + "' alt='" + n + "'/><\/a><div id='TB_caption'>" + n + "<div id='TB_secondLine'>" + TB_imageCount + TB_PrevHTML + TB_NextHTML + "<\/div><\/div><div id='TB_closeWindow' style='float:right;padding:11px 25px 10px 0'><a href='#' id='TB_closeWindowButton' title='Fechar'>Fechar<\/a><\/div>"), $("#TB_closeWindowButton").click(tb_remove), !(TB_PrevHTML === "")) {
                    function goPrev() {
                        return $(document).unbind("click", goPrev) && $(document).unbind("click", goPrev), $("#TB_window").remove(), $("body").append("<div id='TB_window'><\/div>"), tb_show(TB_PrevCaption, TB_PrevURL, i), !1
                    }

                    $("#TB_prev").click(goPrev)
                }
                if (!(TB_NextHTML === "")) {
                    function goNext() {
                        return $("#TB_window").remove(), $("body").append("<div id='TB_window'><\/div>"), tb_show(TB_NextCaption, TB_NextURL, i), !1
                    }

                    $("#TB_next").click(goNext)
                }
                document.onkeydown = function (n) {
                    keycode = n == null ? event.keyCode : n.which;
                    keycode == 27 ? tb_remove() : keycode == 190 ? TB_NextHTML == "" || (document.onkeydown = "", goNext()) : keycode == 188 && (TB_PrevHTML == "" || (document.onkeydown = "", goPrev()))
                };
                tb_position();
                $("#TB_load").remove();
                $("#TB_ImageOff").click(tb_remove);
                $("#TB_window").css({display: "block"})
            };
            imgPreloader.src = t
        } else o = t.replace(/^[^\?]+\??/, ""), r = tb_parseQuery(o), TB_WIDTH = r.width * 1 + 30 || 630, TB_HEIGHT = r.height * 1 + 40 || 440, ajaxContentW = TB_WIDTH - 30, ajaxContentH = TB_HEIGHT - 45, t.indexOf("TB_iframe") != -1 ? (urlNoQuery = t.split("TB_"), $("#TB_iframeContent").remove(), r.modal != "true" ? $("#TB_window").html("<div id='TB_title'><div id='TB_ajaxWindowTitle' style='float:left;padding:7px 0 5px 10px;margin-bottom:1px'>" + n + "<\/div><div id='TB_closeAjaxWindow' style='float:right;padding:7px 10px 5px 0'><a href='#' id='TB_closeWindowButton' title='Fechar'>Fechar<\/a><\/div><\/div><iframe frameborder='0' hspace='0' src='" + urlNoQuery[0] + "' id='TB_iframeContent' name='TB_iframeContent" + Math.round(Math.random() * 1e3) + "' onload='tb_showIframe()' style='width:" + (ajaxContentW + 29) + "px;height:" + (ajaxContentH + 17) + "px;' > <\/iframe>") : ($("#TB_overlay").unbind(), $("#TB_window").append("<iframe frameborder='0' hspace='0' src='" + urlNoQuery[0] + "' id='TB_iframeContent' name='TB_iframeContent" + Math.round(Math.random() * 1e3) + "' onload='tb_showIframe()' style='width:" + (ajaxContentW + 29) + "px;height:" + (ajaxContentH + 17) + "px;'> <\/iframe>"))) : $("#TB_window").css("display") != "block" ? r.modal != "true" ? $("#TB_window").html("<div id='TB_title'><div id='TB_ajaxWindowTitle' style='float:left;padding:7px 0 5px 10px;margin-bottom:1px'>" + n + "<\/div><div id='TB_closeAjaxWindow' style='float:right;padding:7px 10px 5px 0'><a href='#' id='TB_closeWindowButton' title='Fechar'>Fechar<\/a><\/div><\/div><div id='TB_ajaxContent' style='width:" + ajaxContentW + "px;height:" + ajaxContentH + "px;clear:both;overflow:auto;padding:2px 15px 15px 15px'><\/div>") : ($("#TB_overlay").unbind(), $("#TB_window").append("<div id='TB_ajaxContent' class='TB_modal' style='width:" + ajaxContentW + "px;height:" + ajaxContentH + "px;clear:both;overflow:auto;padding:2px 15px 15px 15px'><\/div>")) : ($("#TB_ajaxContent")[0].style.width = ajaxContentW + "px", $("#TB_ajaxContent")[0].style.height = ajaxContentH + "px", $("#TB_ajaxContent")[0].scrollTop = 0, $("#TB_ajaxWindowTitle").html(n)), $("#TB_closeWindowButton").click(tb_remove), t.indexOf("TB_inline") != -1 ? ($("#TB_ajaxContent").append($("#" + r.inlineId).children()), $("#TB_window").unload(function () {
            $("#" + r.inlineId).append($("#TB_ajaxContent").children())
        }), tb_position(), $("#TB_load").remove(), $("#TB_window").css({display: "block"})) : t.indexOf("TB_iframe") != -1 ? (tb_position(), $.browser.safari && ($("#TB_load").remove(), $("#TB_window").css({display: "block"}))) : $("#TB_ajaxContent").load(t += "&random=" + (new Date).getTime(), function () {
            tb_position();
            $("#TB_load").remove();
            tb_init("#TB_ajaxContent a.thickbox");
            $("#TB_window").css({display: "block"})
        });
        r.modal || (document.onkeyup = function (n) {
            keycode = n == null ? event.keyCode : n.which;
            keycode == 27 && tb_remove()
        })
    } catch (h) {
    }
}
function tb_showIframe() {
    $("#TB_load").remove();
    $("#TB_window").css({display: "block"})
}
function tb_remove() {
    return $("#TB_imageOff").unbind("click"), $("#TB_closeWindowButton").unbind("click"), $("#TB_window").fadeOut("fast", function () {
        $("#TB_window,#TB_overlay,#TB_HideSelect").trigger("unload").unbind().remove()
    }), $("#TB_load").remove(), typeof document.body.style.maxHeight == "undefined" && ($("body", "html").css({height: "auto", width: "auto"}), $("html").css("overflow", "")), document.onkeydown = "", document.onkeyup = "", !1
}
function tb_position() {
    $("#TB_window").css({marginLeft: "-" + parseInt(TB_WIDTH / 2, 10) + "px", width: TB_WIDTH + "px"});
    jQuery.browser.msie && jQuery.browser.version < 7 || $("#TB_window").css({marginTop: "-" + parseInt(TB_HEIGHT / 2, 10) + "px"})
}
function tb_parseQuery(n) {
    var u = {}, f, i, t, e, r;
    if (!n)return u;
    for (f = n.split(/[;&]/), i = 0; i < f.length; i++)(t = f[i].split("="), t && t.length == 2) && (e = unescape(t[0]), r = unescape(t[1]), r = r.replace(/\+/g, " "), u[e] = r);
    return u
}
function tb_getPageSize() {
    var n = document.documentElement, t = window.innerWidth || self.innerWidth || n && n.clientWidth || document.body.clientWidth, i = window.innerHeight || self.innerHeight || n && n.clientHeight || document.body.clientHeight;
    return arrayPageSize = [t, i]
}
function tb_detectMacXFF() {
    var n = navigator.userAgent.toLowerCase();
    if (n.indexOf("mac") != -1 && n.indexOf("firefox") != -1)return!0
}
function BindImpersonationMailValidate() {
    $("#impersonation-idmail").length === 0 || $("#impersonation-idmail").hasClass("bound") || ($("#impersonation-idmail").addClass("bound"), $("#impersonation-idmail").unbind("blur").blur(function () {
        var n = $(this).val();
        ImpersonationMailValidate(n)
    }), $("#impersonation-idmail").unbind("keypress").keypress(function (n) {
        var t = n.which;
        t === 13 && ($("#impersonation-search").click(), n.preventDefault())
    }))
}
function ImpersonationMailValidate(n) {
    return n != null && n != "" && n != undefined && (/^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(n) || /^\d+$/.test(n)) ? ($("#impersonation-idmail").removeClass("giftlisterror"), !0) : ($("#impersonation-idmail").addClass("giftlisterror"), $("#impersonation-idmail").stop(!0, !0).fadeOut("fast", function () {
        $("#impersonation-idmail").stop(!0, !0).fadeIn()
    }), !1)
}
function BindImpersonationSearchClick() {
    $("#impersonation-search").length === 0 || $("#impersonation-search").hasClass("bound") || ($("#impersonation-search").addClass("bound"), $("#impersonation-search").unbind("click").click(function (n) {
        n.preventDefault();
        var t = $("#impersonation-idmail").val();
        ImpersonationMailValidate(t) && !$(this).hasClass("clicked") && ($("#impersonation-search, #impersonation-idmail").css("opacity", "0.5"), $("#impersonation-search").addClass("clicked"), t = encodeURIComponent(t), $("#impersonation-result").slideUp("fast"), $("#impersonation-confirm").slideUp("fast"), $.ajax({type: "GET", url: "/no-cache/giftlistv2/impersonation/search/" + t, dataType: "json", success: function (n) {
            $("#impersonation-result").html(n.message);
            n.success ? ($("#impersonation-user").val(n.user), setTimeout(function () {
                $("#impersonation-confirm").slideDown("fast")
            }, 500)) : $("#impersonation-user").val("");
            $("#impersonation-result").slideDown("fast");
            $("#impersonation-search").removeClass("clicked");
            $("#impersonation-search, #impersonation-idmail").css("opacity", "1")
        }, error: function (n, t) {
            $("#impersonation-result").html(t);
            $("#impersonation-user").val("");
            setTimeout(function () {
                $("#impersonation-result").slideUp("slow");
                $("#impersonation-search").removeClass("clicked");
                $("#impersonation-search, #impersonation-idmail").css("opacity", "1")
            }, 6e3)
        }}))
    }))
}
function BindImpersonationContentClick() {
    $("#impersonation-content").length === 0 || $("#impersonation-content").hasClass("bound") || ($("#impersonation-content").addClass("bound"), $("#impersonation-content").unbind("click").click(function (n) {
        (n.preventDefault(), $("#impersonation-content").hasClass("clicked")) || ($("#impersonation-content").addClass("clicked"), $("#impersonation-content").css("opacity", "0.3"), $("#giftlist-impersonation").stop(!0, !0).fadeIn("fast"))
    }))
}
function BindImpersonationConfirmClick() {
    $("#impersonation-confirm").length === 0 || $("#impersonation-confirm").hasClass("bound") || ($("#impersonation-confirm").addClass("bound"), $("#impersonation-confirm").unbind("click").click(function (n) {
        n.preventDefault();
        var t = $("#impersonation-user").val();
        $(this).hasClass("clicked") || t === undefined || t === "" || ($(this).addClass("clicked"), $("#giftlist-impersonation").css("opacity", "0.5"), t = encodeURIComponent(t), $.ajax({type: "POST", url: "?ium=" + t, success: function () {
        }, error: function () {
            setTimeout(function () {
                window.location.href = window.location.protocol + "//" + window.location.hostname
            }, 4e3)
        }}))
    }))
}
function BindImpersonationCloseClick() {
    $("#impersonation-close").length === 0 || $("#impersonation-close").hasClass("bound") || ($("#impersonation-close").addClass("bound"), $("#impersonation-close").unbind("click").click(function (n) {
        n.preventDefault();
        $("#giftlist-impersonation").stop(!0, !0).fadeOut("fast", function () {
            $("#impersonation-result").hide();
            $("#impersonation-confirm").hide();
            $("#impersonation-content").removeClass("clicked");
            $("#impersonation-content").css("opacity", "");
            $("#impersonation-idmail").val("")
        })
    }))
}
function BindImpersonationLogoutClick() {
    $("#impersonation-logout").length === 0 || $("#impersonation-logout").hasClass("bound") || ($("#impersonation-logout").addClass("bound"), $("#impersonation-logout").unbind("click").click(function (n) {
        (n.preventDefault(), $(this).hasClass("clicked")) || ($(this).addClass("clicked"), window.location.href = "/no-cache/user/logout?ium=logout")
    }))
}
function RedirectTimer() {
}
function SendImpersonateUserToCheckout() {
    $("#impersonation-idmail").length !== 0 && $("#impersonation-idmail").val().length !== 0 && vtexjs.checkout.getOrderForm().then(function (n) {
        var t = n.clientProfileData;
        return t.email = $("#impersonation-idmail").val(), vtexjs.checkout.sendAttachment("clientProfileData", t)
    }).done(function (n) {
        console.log("email alterado " + n.clientProfileData.email);
        console.log(n);
        console.log(n.clientProfileData)
    })
}
var JSON, impersonationCount, impersonationCounter;
$(document).ready(function () {
    TrackCall("/Site/Track.aspx")
});
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/thickbox.js
 */
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/
$(document).ajaxStop(function () {
    tb_init("a.thickbox, area.thickbox, input.thickbox")
});
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/json2.js
 */
JSON || (JSON = {}), function () {
    "use strict";
    function f(n) {
        return n < 10 ? "0" + n : n
    }

    function quote(n) {
        return escapable.lastIndex = 0, escapable.test(n) ? '"' + n.replace(escapable, function (n) {
            var t = meta[n];
            return typeof t == "string" ? t : "\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
        }) + '"' : '"' + n + '"'
    }

    function str(n, t) {
        var r, e, u, o, s = gap, f, i = t[n];
        i && typeof i == "object" && typeof i.toJSON == "function" && (i = i.toJSON(n));
        typeof rep == "function" && (i = rep.call(t, n, i));
        switch (typeof i) {
            case"string":
                return quote(i);
            case"number":
                return isFinite(i) ? String(i) : "null";
            case"boolean":
            case"null":
                return String(i);
            case"object":
                if (!i)return"null";
                if (gap += indent, f = [], Object.prototype.toString.apply(i) === "[object Array]") {
                    for (o = i.length, r = 0; r < o; r += 1)f[r] = str(r, i) || "null";
                    return u = f.length === 0 ? "[]" : gap ? "[\n" + gap + f.join(",\n" + gap) + "\n" + s + "]" : "[" + f.join(",") + "]", gap = s, u
                }
                if (rep && typeof rep == "object")for (o = rep.length, r = 0; r < o; r += 1)typeof rep[r] == "string" && (e = rep[r], u = str(e, i), u && f.push(quote(e) + (gap ? ": " : ":") + u)); else for (e in i)Object.prototype.hasOwnProperty.call(i, e) && (u = str(e, i), u && f.push(quote(e) + (gap ? ": " : ":") + u));
                return u = f.length === 0 ? "{}" : gap ? "{\n" + gap + f.join(",\n" + gap) + "\n" + s + "}" : "{" + f.join(",") + "}", gap = s, u
        }
    }

    typeof Date.prototype.toJSON != "function" && (Date.prototype.toJSON = function () {
        return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null
    }, String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function () {
        return this.valueOf()
    });
    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = {"\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\"}, rep;
    typeof JSON.stringify != "function" && (JSON.stringify = function (n, t, i) {
        var r;
        if (gap = "", indent = "", typeof i == "number")for (r = 0; r < i; r += 1)indent += " "; else typeof i == "string" && (indent = i);
        if (rep = t, t && typeof t != "function" && (typeof t != "object" || typeof t.length != "number"))throw new Error("JSON.stringify");
        return str("", {"": n})
    });
    typeof JSON.parse != "function" && (JSON.parse = function (text, reviver) {
        function walk(n, t) {
            var r, u, i = n[t];
            if (i && typeof i == "object")for (r in i)Object.prototype.hasOwnProperty.call(i, r) && (u = walk(i, r), u !== undefined ? i[r] = u : delete i[r]);
            return reviver.call(n, t, i)
        }

        var j;
        if (text = String(text), cx.lastIndex = 0, cx.test(text) && (text = text.replace(cx, function (n) {
            return"\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
        })), /^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, "")))return j = eval("(" + text + ")"), typeof reviver == "function" ? walk({"": j}, "") : j;
        throw new SyntaxError("JSON.parse");
    })
}();
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.viewPart.CallCenterDisclaimer.js
 */
$(document).ajaxStop(function () {
    BindImpersonationContentClick();
    BindImpersonationMailValidate();
    BindImpersonationSearchClick();
    BindImpersonationConfirmClick();
    BindImpersonationCloseClick();
    BindImpersonationLogoutClick();
    SendImpersonateUserToCheckout();
    $("#impersonation-content").hasClass("loading") && ($("#impersonation-content").css("opacity", ""), $("#impersonation-content").removeClass("loading"))
});
impersonationCount = 30;
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.viewPart.ajaxLoader_V2.js
 */
$(document).ready(function () {
    $(".ajax-content-loader").each(function () {
        var n = $(this).attr("rel"), t, i;
        if (typeof n == "undefined" || n === "" || n == null)return window.console && window.console.error && console.error("Nao pode passar o parametro rel vazio para o ajaxloader, verifique o contenturi"), !1;
        t = ___scriptPath + n;
        i = escape(new Date);
        t.indexOf("?", 0) == -1 ? $(this).load(t + "?" + window.location.search.substring(1) + "&h=" + i) : $(this).load(t + "&h=" + i)
    })
})