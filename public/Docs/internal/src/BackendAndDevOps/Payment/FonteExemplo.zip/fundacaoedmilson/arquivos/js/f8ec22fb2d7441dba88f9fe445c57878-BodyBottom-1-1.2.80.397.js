/*! VTEX Commerce Suite Generated */
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/Track.js
 */
function TrackCall(n) {
    var t = location.search, i;
    t.indexOf("utm_source") < 0 && window.defaultUtmFromFolder != "" && (t = "?" + window.defaultUtmFromFolder);
    t == "" ? t = "?" : t += "&";
    i = escape(document.referrer).replace(/\//g, "%2F");
    t += "referrer=" + i;
    $.get(n + t)
}
function tb_init(n) {
    $(n).unbind("click").click(function () {
        var n = this.title || this.name || null, t = this.href || this.alt, i = this.rel || !1;
        return tb_show(n, t, i), this.blur(), !1
    })
}
function tb_show(n, t, i) {
    var e, f, u, s, o, r;
    try {
        if (n == null && t == "" && !i)return;
        if (typeof document.body.style.maxHeight == "undefined" ? ($("body", "html").css({height: "100%", width: "100%"}), $("html").css("overflow", "hidden"), document.getElementById("TB_HideSelect") === null && ($("body").append("<iframe id='TB_HideSelect'><\/iframe><div id='TB_overlay' style='position:fixed;z-index:10000;top:0px;left:0px;height:100%;width:100%'><\/div><div id='TB_window' style='position:fixed;z-index:10002;display:none;top:50%;left:50%'><\/div>"), $("#TB_overlay").click(tb_remove))) : document.getElementById("TB_overlay") === null && ($("body").append("<div id='TB_overlay' style='position:fixed;z-index:10000;top:0px;left:0px;height:100%;width:100%'><\/div><div id='TB_window' style='position:fixed;z-index:10002;display:none;top:50%;left:50%'><\/div>"), $("#TB_overlay").click(tb_remove)), n === null && (n = ""), $("body").append("<div id='TB_load' style='position:fixed;display:none;z-index:10003'><\/div>"), $("#TB_load").show(), e = t.indexOf("?") !== -1 ? t.substr(0, t.indexOf("?")) : t, f = /\.jpg$|\.jpeg$|\.png$|\.gif$|\.bmp$/, u = e.toLowerCase().match(f), u == ".jpg" || u == ".jpeg" || u == ".png" || u == ".gif" || u == ".bmp") {
            if (TB_PrevCaption = "", TB_PrevURL = "", TB_PrevHTML = "", TB_NextCaption = "", TB_NextURL = "", TB_NextHTML = "", TB_imageCount = "", TB_FoundURL = !1, i)for (TB_TempArray = $("a[@rel=" + i + "]").get(), TB_Counter = 0; TB_Counter < TB_TempArray.length && TB_NextHTML === ""; TB_Counter++)s = TB_TempArray[TB_Counter].href.toLowerCase().match(f), TB_TempArray[TB_Counter].href == t ? (TB_FoundURL = !0, TB_imageCount = "Image " + (TB_Counter + 1) + " of " + TB_TempArray.length) : TB_FoundURL ? (TB_NextCaption = TB_TempArray[TB_Counter].title, TB_NextURL = TB_TempArray[TB_Counter].href, TB_NextHTML = "<span id='TB_next'>&nbsp;&nbsp;<a href='#'>Next &gt;<\/a><\/span>") : (TB_PrevCaption = TB_TempArray[TB_Counter].title, TB_PrevURL = TB_TempArray[TB_Counter].href, TB_PrevHTML = "<span id='TB_prev'>&nbsp;&nbsp;<a href='#'>&lt; Prev<\/a><\/span>");
            imgPreloader = new Image;
            imgPreloader.onload = function () {
                imgPreloader.onload = null;
                var o = tb_getPageSize(), f = o[0] - 150, e = o[1] - 150, r = imgPreloader.width, u = imgPreloader.height;
                if (r > f ? (u = u * (f / r), r = f, u > e && (r = r * (e / u), u = e)) : u > e && (r = r * (e / u), u = e, r > f && (u = u * (f / r), r = f)), TB_WIDTH = r + 30, TB_HEIGHT = u + 60, $("#TB_window").append("<a href='' id='TB_ImageOff' title='Close'><img id='TB_Image' src='" + t + "' width='" + r + "' height='" + u + "' alt='" + n + "'/><\/a><div id='TB_caption'>" + n + "<div id='TB_secondLine'>" + TB_imageCount + TB_PrevHTML + TB_NextHTML + "<\/div><\/div><div id='TB_closeWindow' style='float:right;padding:11px 25px 10px 0'><a href='#' id='TB_closeWindowButton' title='Fechar'>Fechar<\/a><\/div>"), $("#TB_closeWindowButton").click(tb_remove), !(TB_PrevHTML === "")) {
                    function goPrev() {
                        return $(document).unbind("click", goPrev) && $(document).unbind("click", goPrev), $("#TB_window").remove(), $("body").append("<div id='TB_window'><\/div>"), tb_show(TB_PrevCaption, TB_PrevURL, i), !1
                    }

                    $("#TB_prev").click(goPrev)
                }
                if (!(TB_NextHTML === "")) {
                    function goNext() {
                        return $("#TB_window").remove(), $("body").append("<div id='TB_window'><\/div>"), tb_show(TB_NextCaption, TB_NextURL, i), !1
                    }

                    $("#TB_next").click(goNext)
                }
                document.onkeydown = function (n) {
                    keycode = n == null ? event.keyCode : n.which;
                    keycode == 27 ? tb_remove() : keycode == 190 ? TB_NextHTML == "" || (document.onkeydown = "", goNext()) : keycode == 188 && (TB_PrevHTML == "" || (document.onkeydown = "", goPrev()))
                };
                tb_position();
                $("#TB_load").remove();
                $("#TB_ImageOff").click(tb_remove);
                $("#TB_window").css({display: "block"})
            };
            imgPreloader.src = t
        } else o = t.replace(/^[^\?]+\??/, ""), r = tb_parseQuery(o), TB_WIDTH = r.width * 1 + 30 || 630, TB_HEIGHT = r.height * 1 + 40 || 440, ajaxContentW = TB_WIDTH - 30, ajaxContentH = TB_HEIGHT - 45, t.indexOf("TB_iframe") != -1 ? (urlNoQuery = t.split("TB_"), $("#TB_iframeContent").remove(), r.modal != "true" ? $("#TB_window").html("<div id='TB_title'><div id='TB_ajaxWindowTitle' style='float:left;padding:7px 0 5px 10px;margin-bottom:1px'>" + n + "<\/div><div id='TB_closeAjaxWindow' style='float:right;padding:7px 10px 5px 0'><a href='#' id='TB_closeWindowButton' title='Fechar'>Fechar<\/a><\/div><\/div><iframe frameborder='0' hspace='0' src='" + urlNoQuery[0] + "' id='TB_iframeContent' name='TB_iframeContent" + Math.round(Math.random() * 1e3) + "' onload='tb_showIframe()' style='width:" + (ajaxContentW + 29) + "px;height:" + (ajaxContentH + 17) + "px;' > <\/iframe>") : ($("#TB_overlay").unbind(), $("#TB_window").append("<iframe frameborder='0' hspace='0' src='" + urlNoQuery[0] + "' id='TB_iframeContent' name='TB_iframeContent" + Math.round(Math.random() * 1e3) + "' onload='tb_showIframe()' style='width:" + (ajaxContentW + 29) + "px;height:" + (ajaxContentH + 17) + "px;'> <\/iframe>"))) : $("#TB_window").css("display") != "block" ? r.modal != "true" ? $("#TB_window").html("<div id='TB_title'><div id='TB_ajaxWindowTitle' style='float:left;padding:7px 0 5px 10px;margin-bottom:1px'>" + n + "<\/div><div id='TB_closeAjaxWindow' style='float:right;padding:7px 10px 5px 0'><a href='#' id='TB_closeWindowButton' title='Fechar'>Fechar<\/a><\/div><\/div><div id='TB_ajaxContent' style='width:" + ajaxContentW + "px;height:" + ajaxContentH + "px;clear:both;overflow:auto;padding:2px 15px 15px 15px'><\/div>") : ($("#TB_overlay").unbind(), $("#TB_window").append("<div id='TB_ajaxContent' class='TB_modal' style='width:" + ajaxContentW + "px;height:" + ajaxContentH + "px;clear:both;overflow:auto;padding:2px 15px 15px 15px'><\/div>")) : ($("#TB_ajaxContent")[0].style.width = ajaxContentW + "px", $("#TB_ajaxContent")[0].style.height = ajaxContentH + "px", $("#TB_ajaxContent")[0].scrollTop = 0, $("#TB_ajaxWindowTitle").html(n)), $("#TB_closeWindowButton").click(tb_remove), t.indexOf("TB_inline") != -1 ? ($("#TB_ajaxContent").append($("#" + r.inlineId).children()), $("#TB_window").unload(function () {
            $("#" + r.inlineId).append($("#TB_ajaxContent").children())
        }), tb_position(), $("#TB_load").remove(), $("#TB_window").css({display: "block"})) : t.indexOf("TB_iframe") != -1 ? (tb_position(), $.browser.safari && ($("#TB_load").remove(), $("#TB_window").css({display: "block"}))) : $("#TB_ajaxContent").load(t += "&random=" + (new Date).getTime(), function () {
            tb_position();
            $("#TB_load").remove();
            tb_init("#TB_ajaxContent a.thickbox");
            $("#TB_window").css({display: "block"})
        });
        r.modal || (document.onkeyup = function (n) {
            keycode = n == null ? event.keyCode : n.which;
            keycode == 27 && tb_remove()
        })
    } catch (h) {
    }
}
function tb_showIframe() {
    $("#TB_load").remove();
    $("#TB_window").css({display: "block"})
}
function tb_remove() {
    return $("#TB_imageOff").unbind("click"), $("#TB_closeWindowButton").unbind("click"), $("#TB_window").fadeOut("fast", function () {
        $("#TB_window,#TB_overlay,#TB_HideSelect").trigger("unload").unbind().remove()
    }), $("#TB_load").remove(), typeof document.body.style.maxHeight == "undefined" && ($("body", "html").css({height: "auto", width: "auto"}), $("html").css("overflow", "")), document.onkeydown = "", document.onkeyup = "", !1
}
function tb_position() {
    $("#TB_window").css({marginLeft: "-" + parseInt(TB_WIDTH / 2, 10) + "px", width: TB_WIDTH + "px"});
    jQuery.browser.msie && jQuery.browser.version < 7 || $("#TB_window").css({marginTop: "-" + parseInt(TB_HEIGHT / 2, 10) + "px"})
}
function tb_parseQuery(n) {
    var u = {}, f, i, t, e, r;
    if (!n)return u;
    for (f = n.split(/[;&]/), i = 0; i < f.length; i++)(t = f[i].split("="), t && t.length == 2) && (e = unescape(t[0]), r = unescape(t[1]), r = r.replace(/\+/g, " "), u[e] = r);
    return u
}
function tb_getPageSize() {
    var n = document.documentElement, t = window.innerWidth || self.innerWidth || n && n.clientWidth || document.body.clientWidth, i = window.innerHeight || self.innerHeight || n && n.clientHeight || document.body.clientHeight;
    return arrayPageSize = [t, i]
}
function tb_detectMacXFF() {
    var n = navigator.userAgent.toLowerCase();
    if (n.indexOf("mac") != -1 && n.indexOf("firefox") != -1)return!0
}
function BindImpersonationMailValidate() {
    $("#impersonation-idmail").length === 0 || $("#impersonation-idmail").hasClass("bound") || ($("#impersonation-idmail").addClass("bound"), $("#impersonation-idmail").unbind("blur").blur(function () {
        var n = $(this).val();
        ImpersonationMailValidate(n)
    }), $("#impersonation-idmail").unbind("keypress").keypress(function (n) {
        var t = n.which;
        t === 13 && ($("#impersonation-search").click(), n.preventDefault())
    }))
}
function ImpersonationMailValidate(n) {
    return n != null && n != "" && n != undefined && (/^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(n) || /^\d+$/.test(n)) ? ($("#impersonation-idmail").removeClass("giftlisterror"), !0) : ($("#impersonation-idmail").addClass("giftlisterror"), $("#impersonation-idmail").stop(!0, !0).fadeOut("fast", function () {
        $("#impersonation-idmail").stop(!0, !0).fadeIn()
    }), !1)
}
function BindImpersonationSearchClick() {
    $("#impersonation-search").length === 0 || $("#impersonation-search").hasClass("bound") || ($("#impersonation-search").addClass("bound"), $("#impersonation-search").unbind("click").click(function (n) {
        n.preventDefault();
        var t = $("#impersonation-idmail").val();
        ImpersonationMailValidate(t) && !$(this).hasClass("clicked") && ($("#impersonation-search, #impersonation-idmail").css("opacity", "0.5"), $("#impersonation-search").addClass("clicked"), t = encodeURIComponent(t), $("#impersonation-result").slideUp("fast"), $("#impersonation-confirm").slideUp("fast"), $.ajax({type: "GET", url: "/no-cache/giftlistv2/impersonation/search/" + t, dataType: "json", success: function (n) {
            $("#impersonation-result").html(n.message);
            n.success ? ($("#impersonation-user").val(n.user), setTimeout(function () {
                $("#impersonation-confirm").slideDown("fast")
            }, 500)) : $("#impersonation-user").val("");
            $("#impersonation-result").slideDown("fast");
            $("#impersonation-search").removeClass("clicked");
            $("#impersonation-search, #impersonation-idmail").css("opacity", "1")
        }, error: function (n, t) {
            $("#impersonation-result").html(t);
            $("#impersonation-user").val("");
            setTimeout(function () {
                $("#impersonation-result").slideUp("slow");
                $("#impersonation-search").removeClass("clicked");
                $("#impersonation-search, #impersonation-idmail").css("opacity", "1")
            }, 6e3)
        }}))
    }))
}
function BindImpersonationContentClick() {
    $("#impersonation-content").length === 0 || $("#impersonation-content").hasClass("bound") || ($("#impersonation-content").addClass("bound"), $("#impersonation-content").unbind("click").click(function (n) {
        (n.preventDefault(), $("#impersonation-content").hasClass("clicked")) || ($("#impersonation-content").addClass("clicked"), $("#impersonation-content").css("opacity", "0.3"), $("#giftlist-impersonation").stop(!0, !0).fadeIn("fast"))
    }))
}
function BindImpersonationConfirmClick() {
    $("#impersonation-confirm").length === 0 || $("#impersonation-confirm").hasClass("bound") || ($("#impersonation-confirm").addClass("bound"), $("#impersonation-confirm").unbind("click").click(function (n) {
        n.preventDefault();
        var t = $("#impersonation-user").val();
        $(this).hasClass("clicked") || t === undefined || t === "" || ($(this).addClass("clicked"), $("#giftlist-impersonation").css("opacity", "0.5"), t = encodeURIComponent(t), $.ajax({type: "POST", url: "?ium=" + t, success: function () {
        }, error: function () {
            setTimeout(function () {
                window.location.href = window.location.protocol + "//" + window.location.hostname
            }, 4e3)
        }}))
    }))
}
function BindImpersonationCloseClick() {
    $("#impersonation-close").length === 0 || $("#impersonation-close").hasClass("bound") || ($("#impersonation-close").addClass("bound"), $("#impersonation-close").unbind("click").click(function (n) {
        n.preventDefault();
        $("#giftlist-impersonation").stop(!0, !0).fadeOut("fast", function () {
            $("#impersonation-result").hide();
            $("#impersonation-confirm").hide();
            $("#impersonation-content").removeClass("clicked");
            $("#impersonation-content").css("opacity", "");
            $("#impersonation-idmail").val("")
        })
    }))
}
function BindImpersonationLogoutClick() {
    $("#impersonation-logout").length === 0 || $("#impersonation-logout").hasClass("bound") || ($("#impersonation-logout").addClass("bound"), $("#impersonation-logout").unbind("click").click(function (n) {
        (n.preventDefault(), $(this).hasClass("clicked")) || ($(this).addClass("clicked"), window.location.href = "/no-cache/user/logout?ium=logout")
    }))
}
function RedirectTimer() {
}
function SendImpersonateUserToCheckout() {
    $("#impersonation-idmail").length !== 0 && $("#impersonation-idmail").val().length !== 0 && vtexjs.checkout.getOrderForm().then(function (n) {
        var t = n.clientProfileData;
        return t.email = $("#impersonation-idmail").val(), vtexjs.checkout.sendAttachment("clientProfileData", t)
    }).done(function (n) {
        console.log("email alterado " + n.clientProfileData.email);
        console.log(n);
        console.log(n.clientProfileData)
    })
}
function ArrayGet(n) {
    for (var t = 0; t < selectedToInsert.length;) {
        if (selectedToInsert[t] == n || selectedToInsert[t].indexOf(n + "-") === 0)return selectedToInsert[t];
        t++
    }
    return""
}
function ArrayRemove(n) {
    for (var i = !1, t = 0; t < selectedToInsert.length && !i;)(selectedToInsert[t] == n || selectedToInsert[t].indexOf(n + "-") === 0) && (selectedToInsert.splice(t, 1), i = !0), t++
}
function ArrayContains(n) {
    for (i = 0; i < selectedToInsert.length; i++)if (selectedToInsert[i] == n || selectedToInsert[i].indexOf(n + "-") === 0)return!0;
    return!1
}
function IsAuthenticated() {
    if ($(".giftlist-insertsku-must-login").length === 0) {
        $(".product-insertsku").length > 0 && ($(".product-insertsku").removeClass("must-login"), $(".product-insertsku").stop(!0, !0).show());
        return
    }
    $(".glis-sku-listtolist").stop(!0, !0).slideUp("fast");
    $(".glis-sku-single").stop(!0, !0).slideUp("fast");
    $(".glis-sku-select").stop(!0, !0).slideUp("fast");
    $(".product-insertsku").stop(!0, !0).slideUp("fast")
}
function CheckThickBox() {
    $(".glis-thickbox").each(function (n, t) {
        $(t).hasClass("tb-added") || ($(t).addClass("tb-added"), tb_init("#" + $(t).attr("id")))
    })
}
function BindSkuDataListener() {
    if ("undefined" != typeof skuEventDispatcher && "undefined" != typeof skuDataReceivedEventName) {
        var n = new Vtex.JSEvents.Listener("giftListInsertSkuV2Listener", InsertSkuV2_OnSkuDataReceived);
        skuEventDispatcher.addListener(skuDataReceivedEventName, n)
    }
}
function InsertSkuV2_OnSkuDataReceived(n) {
    "undefined" == typeof n || n.skuData.id < 1 || ($(".glis-sku-select-checklist").length > 0 ? ChangeSelectedList(n) : $(".glis-sku-single-item").length > 0 && ChangeSelectedSingle(n))
}
function ChangeSelectedSingle(n) {
    selectedToInsert = new Array(0);
    selectedToInsert.add(n.skuData.id + "-1");
    $(".glis-sku-single-item").removeClass("unavailable");
    $(".glis-sku-single-item").text(n.skuData.name);
    $(".insert-sku-quantity").val(1);
    $(".glis-sku-single-item").fadeOut("fast", function () {
        $(".hidden-sku-default").text(n.skuData.id);
        n.skuData.availability || $(".glis-sku-single-item").addClass("unavailable")
    });
    $(".glis-sku-single-item").fadeIn("slow")
}
function ChangeSelectedList(n) {
    var t = $(".glis-sku-select-checklist:first");
    $(t).find(".insert-sku-checkbox:checked").length < 2 && (selectedToInsert = new Array(0), selectedToInsert.add(n.skuData.id + "-1"), $(".insert-sku-checkbox:checked").attr("checked", !1), $(".insert-sku-checkbox[rel=" + n.skuData.id + "]").attr("checked", !0), onInsertSkuCheckBoxClick($(t).find(".insert-sku-checkbox[rel=" + n.skuData.id + "]:first")));
    n.skuData.availability || $(".insert-sku-checkbox[rel=" + n.skuData.id + "]").parent().addClass("unavailable")
}
function BindEvents() {
    BindInsertSkuListToList();
    BindInsertSkuCheckBox();
    BindInsertSkuQuantity();
    InsertQuantityKeypress();
    InsertQuantityFocus();
    BindInsertSkuSubmitCombo();
    BindInsertSkuSubmitRadio();
    BindInsertSkuSubmitList();
    BindInsertSkuSubmitNew();
    PreCheckSkuSelect();
    BindSelectTypeChange()
}
function BindInsertSkuSubmitCombo() {
    $(".glis-submit-combo").unbind("click").click(function (n) {
        $(".glis-submit.clicked").length > 0 || (n.stopImmediatePropagation(), $(this).addClass("clicked"), AddToListCombo($(this).attr("id").split("_")[1]))
    })
}
function BindSelectTypeChange() {
    $(".glis-newlisttype").unbind("change").change(function () {
        $("#" + $(this).attr("id") + " option:selected").attr("redirect") === "true" ? ($(".glis-new-address-info").stop(!0, !0).slideDown("slow"), $(".glis-new-info").stop(!0, !0).slideUp("fast")) : ($(".glis-new-address-info").stop(!0, !0).slideUp("fast"), $(".glis-new-info").stop(!0, !0).slideDown("slow"))
    })
}
function BindInsertSkuSubmitRadio() {
    $(".glis-submit-radio").unbind("click").click(function (n) {
        $(".glis-submit.clicked").length > 0 || (n.stopImmediatePropagation(), $(this).addClass("clicked"), AddToListRadio($(this).attr("id").split("_")[1]))
    })
}
function BindInsertSkuSubmitList() {
    $(".glis-submit-list").unbind("click").click(function (n) {
        $(".glis-submit.clicked").length > 0 || (n.stopImmediatePropagation(), $(this).addClass("clicked"), AddToList($(this).attr("id").split("_")[1]))
    })
}
function BindInsertSkuSubmitNew() {
    $(".glis-submit-new").unbind("click").click(function (n) {
        $(".glis-submit.clicked").length > 0 || (n.stopImmediatePropagation(), $(this).addClass("clicked"), AddToListNew(this))
    })
}
function BindInsertSkuQuantity() {
    $(".insert-sku-quantity").unbind("blur").blur(function (n) {
        n.stopImmediatePropagation();
        onChangeInsertQuantity(this)
    });
    $(".insert-sku-quantity").unbind("focus").focus(function (n) {
        setTimeout(function () {
            n.target.select()
        }, 0)
    })
}
function BindInsertSkuListToList() {
    var n = ".glis-listtolist-checkbox";
    $(n).length !== 0 && ($(n).attr("addedclick") != "yes" && $(n).unbind("click").click(function (n) {
        n.stopImmediatePropagation();
        onInsertSkuListToListClick(this)
    }), $(n).attr("addedclick", "yes"), PreCheckInsertSkuCheckBox(), PreCheckInsertSkuQuantity())
}
function BindInsertSkuCheckBox() {
    var n = ".insert-sku-checkbox";
    $(n).length !== 0 && ($(n).attr("addedclick") != "yes" && $(n).unbind("click").click(function (n) {
        n.stopImmediatePropagation();
        onInsertSkuCheckBoxClick(this)
    }), $(n).attr("addedclick", "yes"), PreCheckInsertSkuCheckBox(), PreCheckInsertSkuQuantity())
}
function PreCheckInsertSkuCheckBox() {
    var n = ".insert-sku-checkbox:enabled";
    $(n).length !== 0 && ($(n).each(function (n, t) {
        var i = $(t).attr("rel");
        t.checked = ArrayContains(i)
    }), $(".glis-listtolist-checkbox:checked").length > 0 && $(".insert-sku-checkbox").attr("disabled", "disabled"))
}
function PreCheckInsertSkuQuantity() {
    var n = ".insert-sku-quantity";
    $(n).length !== 0 && ($(n).each(function (n, t) {
        var u = $("#chk-" + $(t).attr("id").split("-")[1]), i = 1, r;
        $(u).is(":checked") && (r = ArrayGet($(u).attr("rel")).split("-")[1], r > i && (i = r));
        $(t).val(i)
    }), $(".glis-listtolist-checkbox:checked").length > 0 && $(".insert-sku-quantity").attr("disabled", "disabled"))
}
function PreCheckSkuSelect() {
    var t, n;
    $(".hidden-sku-default").length !== 0 && (t = $(".hidden-sku-default:first").text(), selectedToInsert = new Array(0), n = $(".hidden-sku-default:first").parent().find(".insert-sku-quantity").val(), selectedToInsert.add(t + "-" + n), updateInsertSkuSelectionCount("+", n))
}
function onInsertSkuListToListClick(n) {
    var u, t, r, i;
    if ($(".glis-listtolist-checkbox").attr("checked", n.checked), u = "+", t = 0, $(selectedToInsert).each(function (n) {
        t += parseInt(selectedToInsert[n].split("-")[1])
    }), selectedToInsert = new Array(0), n.checked) {
        for ($(".insert-sku-checkbox").attr("checked", !0), $(".insert-sku-checkbox").attr("disabled", "disabled"), $(".insert-sku-quantity").attr("disabled", "disabled"), t = 0, r = $(n).first().val().split(","), i = 0; i < r.length; i++)t += parseInt(r[i].split("-")[1]), selectedToInsert.add(r[i]);
        $(".insert-sku-count").parent().addClass("checked")
    } else $(".insert-sku-checkbox").attr("checked", !1), $(".insert-sku-checkbox").removeAttr("disabled"), $(".insert-sku-quantity").removeAttr("disabled"), u = "-", $(".insert-sku-count").parent().removeClass("checked");
    updateInsertSkuSelectionCount(u, t);
    PreCheckInsertSkuQuantity()
}
function onInsertSkuCheckBoxClick(n) {
    var r, i, e;
    if (!($(".glis-listtolist-checkbox:checked").length > 0)) {
        var u = $(n).attr("id"), t = $(n).attr("rel"), o = $(n).attr("id").split("-")[1], f = "+";
        n.checked ? (r = 1, i = $("#isq-" + o), $(i).length > 0 && !isNaN($(i).val()) && ($(i).stop(!0, !0).fadeOut("fast"), r = $(i).val(), $(i).stop(!0, !0).fadeIn("slow")), ArrayContains(t) || selectedToInsert.add(t + "-" + r), $("label[for='" + u + "']").addClass("checked")) : (f = "-", r = ArrayGet(t).split("-")[1], ArrayContains(t) && ArrayRemove(t), $("label[for='" + u + "']").removeClass("checked"));
        updateInsertSkuSelectionCount(f, r);
        e = ".insert-sku-checkbox[rel={0}]".format(t);
        $(e).attr("checked", n.checked)
    }
}
function onChangeInsertQuantity(n) {
    var t, u;
    if (!($(".glis-listtolist-checkbox:checked").length > 0)) {
        if (t = $(n).val(), isNaN(t) || t < 1) {
            $(n).addClass("giftlisterror");
            $(".insert-sku-quantity").val(1);
            $(".glis-submit").removeClass("clicked");
            return
        }
        var e = $(n).attr("id").split("-")[1], o = $("#chk-" + e), s = $(".glis-sku-single-item[name=" + e + "]"), i = 0, r = 0, f = !1;
        if ($(o).each(function (n, u) {
            var e = $(u).attr("rel");
            ArrayContains(e) && t != ArrayGet(e).split("-")[1] && (r += ArrayGet(e).split("-")[1], i += t, ArrayRemove(e), selectedToInsert.add(e + "-" + t), f = !0)
        }), s.length > 0 && ($(".insert-sku-quantity").val(t), u = $(".hidden-sku-default:first").text(), ArrayContains(u) && t != ArrayGet(u).split("-")[1] && (r += ArrayGet(u).split("-")[1], i += t, ArrayRemove(u), selectedToInsert.add(u + "-" + t), f = !0)), !f || i === r) {
            $(".glis-submit").removeClass("clicked");
            return
        }
        $(n).stop(!0, !0).fadeOut("fast");
        i > r ? updateInsertSkuSelectionCount("+", i - r) : i < r && updateInsertSkuSelectionCount("-", r - i);
        $(n).stop(!0, !0).fadeIn("slow")
    }
}
function updateInsertSkuSelectionCount(n, t) {
    var i = n == "+" ? "qty-plus" : "qty-minus";
    $(".glis-selected-amount").length > 0 && $(".glis-selected-amount").each(function (n, i) {
        i.innerHTML = selectedToInsert.length;
        t > 0 && ($(".glis-selected").removeClass("giftlisterror"), $(".glis-submit").removeClass("clicked"))
    });
    $(".glis-flash-quantity-added").length > 0 && $(".glis-flash-quantity-added").each(function (r, u) {
        u.innerHTML = n + t;
        $(u).addClass(i);
        setTimeout(function () {
            $(u).stop(!0, !0).fadeIn("fast")
        }, 300);
        setTimeout(function () {
            $(u).stop(!0, !0).fadeOut("slow", function () {
                $(u).removeClass(i)
            })
        }, 1e3)
    });
    PopupCheckAmountToAdd()
}
function PopupCheckAmountToAdd() {
    $(".glis-popup-link-add").length > 0 && selectedToInsert.length > 0 ? $(".glis-popup-link-add").stop(!0, !0).fadeOut("fast", function () {
        $(".glis-popup-link").stop(!0, !0).fadeIn("slow")
    }) : $(".glis-popup-link").length > 0 && selectedToInsert.length === 0 && $(".glis-popup-link").stop(!0, !0).fadeOut("fast", function () {
        $(".glis-popup-link-add").stop(!0, !0).fadeIn("slow")
    })
}
function AddToListCombo(n) {
    var t = $("#" + n).find(":selected").val(), i = $("#" + n).find(":selected").text();
    SendData(Config.UrlExistingList, GetPostData(t), function (t) {
        AddedToExistingList("#" + n, t)
    })
}
function AddToListRadio(n) {
    var t = $("input:radio[name=" + n + "]:checked"), i = t.val(), u = $("#for-" + t.attr("id")).text(), r = "#for-" + $(t).attr("id");
    SendData(Config.UrlExistingList, GetPostData(i), function (n) {
        AddedToExistingList(r, n)
    })
}
function AddToList(n) {
    var t = $("#bt_" + n).attr("rel"), i = $("#bt_" + n).text();
    SendData(Config.UrlExistingList, GetPostData(t), function (n) {
        AddedToExistingList(".glis-submit-list[rel=" + t + "]", n)
    })
}
function AddedToExistingList(n, t) {
    t.Success ? (ShowInsertedSuccess(!1, t), FlashJustAdded(n)) : ShowErrorMessage(n, t.Error)
}
function FlashJustAdded(n) {
    $(n).length !== 0 && ($(n).stop(!0, !0).fadeOut("fast", function () {
        $(n).addClass("updated")
    }), $(n).stop(!0, !0).fadeIn(), setTimeout(function () {
        $(n).removeClass("updated")
    }, 6e3))
}
function AddToListNew(n) {
    var t = $(n).attr("rel"), i = $("#new_" + t).val(), r, o;
    if (i.trim() === "") {
        $("#new_" + t).addClass("giftlisterror");
        $(n).removeClass("clicked");
        $("#new_" + t).is(":animated") || $("#new_" + t).fadeOut("fast").fadeIn("fast");
        return
    }
    var a = $("#glis-type_" + t).val(), u = $("#glis-type_" + t).val(), v = $("#glis-type_" + t + " option:selected").text(), s = $("#glis-type_" + t + " option:selected").attr("redirect") === "true", h = ($(".hidden-glis-addtoquantity").first().text() || "true").toLowerCase() == "true", c = {GiftListName: i, GiftListTypeId: u, UrlFolder: "", CheckedItems: selectedToInsert, AddToQuantity: h};
    if (s) {
        r = $(".hidden-glis-create-url").first().text();
        r += r.indexOf("?", 0) > -1 ? "&" : "?";
        i = encodeURIComponent(i);
        var l = selectedToInsert.join(","), f = "{0}n={1}&t={2}&i={3}".format(r, i, u, l), e = $(".hidden-glis-address-message-add").first().text();
        if (f.length > 1930 && (f = "{0}n={1}&t={2}".format(r, i, u), e = $(".hidden-glis-address-message-noadd").first().text()), o = "{0} - {1}".format($(".hidden-glis-address-message").first().text(), e), !confirm(o))return;
        window.location.href = f
    } else SendData(Config.UrlNewList, c, function (n) {
        NewListCreated(t, n)
    })
}
function NewListCreated(n, t) {
    t.Success ? (ShowInsertedSuccess(!0, t), setTimeout(function () {
        $(".giftlist-insertsku").each(function (n, t) {
            NewListCreatedReload(t)
        })
    }, 5e3)) : ShowErrorMessage("#glis-create_" + n, t.Error)
}
function NewListCreatedReload(n) {
    var t = $(n).attr("id");
    Config.GetUrlContent(t).length !== 0 && jQuery.ajax({type: "POST", url: Config.GetUrlContent(t), data: "", success: function (n) {
        $("#" + t).stop(!0, !0).fadeOut("fast");
        $("#" + t).html(n);
        $("#" + t).stop(!0, !0).fadeIn("slow")
    }, error: function () {
        window.top.location.href = window.top.location.href
    }})
}
function ShowInsertedSuccess(n, t) {
    var i, r, u;
    $(".glis-save").stop(!0, !0).hide();
    $(".glis-save").html("");
    $(".glis-create").stop(!0, !0).slideUp("fast");
    $(".glis-save").append("<ul>");
    n && $(".glis-save > ul").append($(".glis-save-title-new"));
    t.InsertedSkus > 0 && (i = $(".glis-save-inserted")[0].outerHTML.replace("#quantidade#", t.InsertedSkus), i = t.InsertedSkus > 1 ? i.replace(/\(s\)/g, "s").replace(/\(S\)/g, "S").replace(/\(m\)/g, "m").replace(/\(M\)/g, "M") : i.replace(/\(s\)/g, "").replace(/\(S\)/g, "").replace(/\(m\)/g, "").replace(/\(M\)/g, ""), $(".glis-save > ul").append(i));
    t.ExistingSkus > 0 && (r = $(".glis-save-existing")[0].outerHTML.replace("#quantidade#", t.ExistingSkus), r = t.ExistingSkus > 1 ? r.replace(/\(s\)/g, "s").replace(/\(S\)/g, "S").replace(/\(m\)/g, "m").replace(/\(M\)/g, "M") : r.replace(/\(s\)/g, "").replace(/\(S\)/g, "").replace(/\(m\)/g, "").replace(/\(M\)/g, ""), $(".glis-save > ul").append(r));
    $(".glis-save > ul").children(".glis-save-edit").length === 0 && (u = $(".glis-save-edit")[0].outerHTML.replace("/giftlist/manage", $(".hidden-glis-edit-url").first().text() + "?id=" + t.GiftListId), $(".glis-save > ul").append(u));
    $(".glis-save").addClass("save-success");
    $(".glis-save").stop(!0, !0).slideDown("slow");
    setTimeout(function () {
        $(".glis-save").stop(!0, !0).slideUp("slow", function () {
            n || ($(".glis-create").stop(!0, !0).slideDown("fast"), $(".glis-submit").removeClass("clicked"));
            $(".glis-save").removeClass("save-success");
            $(".glis-save").html("")
        })
    }, 6e3)
}
function ShowErrorMessage(n, t) {
    n.length !== 0 && $(n).length !== 0 && ($(".glis-save").stop(!0, !0).hide(), $(".glis-save").addClass("save-error"), $(".glis-save").html(t), $(".glis-save").stop(!0, !0).fadeIn("fast"), setTimeout(function () {
        $(".glis-save").stop(!0, !0).fadeOut("slow", function () {
            $(".glis-save").removeClass("save-error");
            $(".glis-save").html("")
        })
    }, t.length * 30))
}
function AddToListCheckSelected() {
    return selectedToInsert.length === 0 ? ($(".glis-selected").addClass("giftlisterror"), $(".glis-submit").removeClass("clicked"), !1) : !0
}
function GetPostData(n) {
    var t = ($(".hidden-glis-addtoquantity").first().text() || "true").toLowerCase() == "true";
    return{GiftListId: n, CheckedItems: selectedToInsert, AddToQuantity: t}
}
function SendData(n, t, i) {
    AddToListCheckSelected() && $.ajax({type: "POST", url: n, dataType: "json", contentType: "application/json; charset=utf-8", data: ko.toJSON(t), success: function (n) {
        typeof n != "undefined" && i(n)
    }, error: function (n) {
        $(".list-form-box").html(n.responseText);
        $(".glis-submit").removeClass("clicked")
    }})
}
function InsertQuantityKeypress() {
    $(".insert-sku-quantity").keypress(function (n) {
        var t = [], r = n.which, i;
        for (r === 13 && n.preventDefault(), t.push(8), t.push(37), t.push(38), t.push(39), t.push(40), t.push(46), i = 48; i < 58; i++)t.push(i);
        t.indexOf(r) >= 0 || n.preventDefault()
    })
}
function InsertQuantityFocus() {
    $(".insert-sku-quantity").focus(function (n) {
        ClearInputError(n)
    })
}
function ClearInputError(n) {
    $(n).removeClass("giftlisterror");
    $(".glis-submit").removeClass("clicked")
}
var JSON, impersonationCount, impersonationCounter, selectedToInsert, Config;
$(document).ready(function () {
    TrackCall("/Site/Track.aspx")
});
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/thickbox.js
 */
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/
$(document).ajaxStop(function () {
    tb_init("a.thickbox, area.thickbox, input.thickbox")
});
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/json2.js
 */
JSON || (JSON = {}), function () {
    "use strict";
    function f(n) {
        return n < 10 ? "0" + n : n
    }

    function quote(n) {
        return escapable.lastIndex = 0, escapable.test(n) ? '"' + n.replace(escapable, function (n) {
            var t = meta[n];
            return typeof t == "string" ? t : "\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
        }) + '"' : '"' + n + '"'
    }

    function str(n, t) {
        var r, e, u, o, s = gap, f, i = t[n];
        i && typeof i == "object" && typeof i.toJSON == "function" && (i = i.toJSON(n));
        typeof rep == "function" && (i = rep.call(t, n, i));
        switch (typeof i) {
            case"string":
                return quote(i);
            case"number":
                return isFinite(i) ? String(i) : "null";
            case"boolean":
            case"null":
                return String(i);
            case"object":
                if (!i)return"null";
                if (gap += indent, f = [], Object.prototype.toString.apply(i) === "[object Array]") {
                    for (o = i.length, r = 0; r < o; r += 1)f[r] = str(r, i) || "null";
                    return u = f.length === 0 ? "[]" : gap ? "[\n" + gap + f.join(",\n" + gap) + "\n" + s + "]" : "[" + f.join(",") + "]", gap = s, u
                }
                if (rep && typeof rep == "object")for (o = rep.length, r = 0; r < o; r += 1)typeof rep[r] == "string" && (e = rep[r], u = str(e, i), u && f.push(quote(e) + (gap ? ": " : ":") + u)); else for (e in i)Object.prototype.hasOwnProperty.call(i, e) && (u = str(e, i), u && f.push(quote(e) + (gap ? ": " : ":") + u));
                return u = f.length === 0 ? "{}" : gap ? "{\n" + gap + f.join(",\n" + gap) + "\n" + s + "}" : "{" + f.join(",") + "}", gap = s, u
        }
    }

    typeof Date.prototype.toJSON != "function" && (Date.prototype.toJSON = function () {
        return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null
    }, String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function () {
        return this.valueOf()
    });
    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = {"\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\"}, rep;
    typeof JSON.stringify != "function" && (JSON.stringify = function (n, t, i) {
        var r;
        if (gap = "", indent = "", typeof i == "number")for (r = 0; r < i; r += 1)indent += " "; else typeof i == "string" && (indent = i);
        if (rep = t, t && typeof t != "function" && (typeof t != "object" || typeof t.length != "number"))throw new Error("JSON.stringify");
        return str("", {"": n})
    });
    typeof JSON.parse != "function" && (JSON.parse = function (text, reviver) {
        function walk(n, t) {
            var r, u, i = n[t];
            if (i && typeof i == "object")for (r in i)Object.prototype.hasOwnProperty.call(i, r) && (u = walk(i, r), u !== undefined ? i[r] = u : delete i[r]);
            return reviver.call(n, t, i)
        }

        var j;
        if (text = String(text), cx.lastIndex = 0, cx.test(text) && (text = text.replace(cx, function (n) {
            return"\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
        })), /^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, "")))return j = eval("(" + text + ")"), typeof reviver == "function" ? walk({"": j}, "") : j;
        throw new SyntaxError("JSON.parse");
    })
}();
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.viewPart.CallCenterDisclaimer.js
 */
$(document).ajaxStop(function () {
    BindImpersonationContentClick();
    BindImpersonationMailValidate();
    BindImpersonationSearchClick();
    BindImpersonationConfirmClick();
    BindImpersonationCloseClick();
    BindImpersonationLogoutClick();
    SendImpersonateUserToCheckout();
    $("#impersonation-content").hasClass("loading") && ($("#impersonation-content").css("opacity", ""), $("#impersonation-content").removeClass("loading"))
});
impersonationCount = 30;
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.viewPart.ajaxLoader_V2.js
 */
$(document).ready(function () {
    $(".ajax-content-loader").each(function () {
        var n = $(this).attr("rel"), t, i;
        if (typeof n == "undefined" || n === "" || n == null)return window.console && window.console.error && console.error("Nao pode passar o parametro rel vazio para o ajaxloader, verifique o contenturi"), !1;
        t = ___scriptPath + n;
        i = escape(new Date);
        t.indexOf("?", 0) == -1 ? $(this).load(t + "?" + window.location.search.substring(1) + "&h=" + i) : $(this).load(t + "&h=" + i)
    })
});
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/knockout-2.1.0.js
 */
(function (n, t, i) {
    function o(n) {
        throw n;
    }

    function s(n) {
        return function () {
            return n
        }
    }

    function h(h) {
        function v(n, t, i) {
            i && t !== c.k.r(n) && c.k.S(n, t);
            t !== c.k.r(n) && c.a.va(n, "change")
        }

        var c = "undefined" != typeof h ? h : {}, y, l, a;
        c.b = function (n, t) {
            for (var i = n.split("."), r = c, u = 0; u < i.length - 1; u++)r = r[i[u]];
            r[i[i.length - 1]] = t
        };
        c.B = function (n, t, i) {
            n[t] = i
        };
        c.version = "2.1.0";
        c.b("version", c.version);
        c.a = new function () {
            function v(n, t) {
                if ("input" !== c.a.o(n) || !n.type || "click" != t.toLowerCase())return f;
                var i = n.type;
                return"checkbox" == i || "radio" == i
            }

            var k = /^(\s|\u00A0)+|(\s|\u00A0)+$/g, h = {}, p = {}, y, l, a, w, b, s;
            h[/Firefox\/2/i.test(i.userAgent) ? "KeyboardEvent" : "UIEvents"] = ["keyup", "keydown", "keypress"];
            h.MouseEvents = "click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave".split(" ");
            for (y in h)if (l = h[y], l.length)for (a = 0, w = l.length; a < w; a++)p[l[a]] = y;
            return b = {propertychange: r}, s = function () {
                for (var n = 3, i = t.createElement("div"), r = i.getElementsByTagName("i"); i.innerHTML = "<!--[if gt IE " + ++n + "]><i><\/i><![endif]-->", r[0];);
                return 4 < n ? n : e
            }(), {Ca: ["authenticity_token", /^__RequestVerificationToken(_.*)?$/], v: function (n, t) {
                for (var i = 0, r = n.length; i < r; i++)t(n[i])
            }, j: function (n, t) {
                if ("function" == typeof Array.prototype.indexOf)return Array.prototype.indexOf.call(n, t);
                for (var i = 0, r = n.length; i < r; i++)if (n[i] === t)return i;
                return-1
            }, ab: function (n, t, i) {
                for (var r = 0, f = n.length; r < f; r++)if (t.call(i, n[r]))return n[r];
                return u
            }, ba: function (n, t) {
                var i = c.a.j(n, t);
                0 <= i && n.splice(i, 1)
            }, za: function (n) {
                for (var n = n || [], i = [], t = 0, r = n.length; t < r; t++)0 > c.a.j(i, n[t]) && i.push(n[t]);
                return i
            }, T: function (n, t) {
                for (var n = n || [], r = [], i = 0, u = n.length; i < u; i++)r.push(t(n[i]));
                return r
            }, aa: function (n, t) {
                for (var n = n || [], r = [], i = 0, u = n.length; i < u; i++)t(n[i]) && r.push(n[i]);
                return r
            }, N: function (n, t) {
                if (t instanceof Array)n.push.apply(n, t); else for (var i = 0, r = t.length; i < r; i++)n.push(t[i]);
                return n
            }, extend: function (n, t) {
                if (t)for (var i in t)t.hasOwnProperty(i) && (n[i] = t[i]);
                return n
            }, ga: function (n) {
                for (; n.firstChild;)c.removeNode(n.firstChild)
            }, Ab: function (n) {
                for (var n = c.a.L(n), r = t.createElement("div"), i = 0, u = n.length; i < u; i++)c.F(n[i]), r.appendChild(n[i]);
                return r
            }, X: function (n, t) {
                if (c.a.ga(n), t)for (var i = 0, r = t.length; i < r; i++)n.appendChild(t[i])
            }, Na: function (n, t) {
                var r = n.nodeType ? [n] : n;
                if (0 < r.length) {
                    for (var f = r[0], e = f.parentNode, i = 0, u = t.length; i < u; i++)e.insertBefore(t[i], f);
                    for (i = 0, u = r.length; i < u; i++)c.removeNode(r[i])
                }
            }, Pa: function (n, t) {
                0 <= i.userAgent.indexOf("MSIE 6") ? n.setAttribute("selected", t) : n.selected = t
            }, w: function (n) {
                return(n || "").replace(k, "")
            }, Ib: function (n, t) {
                for (var r, u = [], f = (n || "").split(t), i = 0, e = f.length; i < e; i++)r = c.a.w(f[i]), "" !== r && u.push(r);
                return u
            }, Hb: function (n, t) {
                return n = n || "", t.length > n.length ? f : n.substring(0, t.length) === t
            }, eb: function (n, t) {
                for (var i = "return (" + n + ")", r = 0; r < t; r++)i = "with(sc[" + r + "]) { " + i + " } ";
                return new Function("sc", i)
            }, kb: function (n, t) {
                if (t.compareDocumentPosition)return 16 == (t.compareDocumentPosition(n) & 16);
                for (; n != u;) {
                    if (n == t)return r;
                    n = n.parentNode
                }
                return f
            }, fa: function (n) {
                return c.a.kb(n, n.ownerDocument)
            }, o: function (n) {
                return n && n.tagName && n.tagName.toLowerCase()
            }, n: function (n, t, i) {
                var u = s && b[t], e, i;
                u || "undefined" == typeof jQuery ? !u && "function" == typeof n.addEventListener ? n.addEventListener(t, i, f) : "undefined" != typeof n.attachEvent ? n.attachEvent("on" + t, function (t) {
                    i.call(n, t)
                }) : o(Error("Browser doesn't support addEventListener or attachEvent")) : (v(n, t) && (e = i, i = function (n, t) {
                    var i = this.checked;
                    t && (this.checked = t.fb !== r);
                    e.call(this, n);
                    this.checked = i
                }), jQuery(n).bind(t, i))
            }, va: function (i, u) {
                if (i && i.nodeType || o(Error("element must be a DOM node when calling triggerEvent")), "undefined" != typeof jQuery) {
                    var e = [];
                    v(i, u) && e.push({fb: i.checked});
                    jQuery(i).trigger(u, e)
                } else"function" == typeof t.createEvent ? "function" == typeof i.dispatchEvent ? (e = t.createEvent(p[u] || "HTMLEvents"), e.initEvent(u, r, r, n, 0, 0, 0, 0, 0, f, f, f, f, 0, i), i.dispatchEvent(e)) : o(Error("The supplied element doesn't support dispatchEvent")) : "undefined" != typeof i.fireEvent ? (v(i, u) && (i.checked = i.checked !== r), i.fireEvent("on" + u)) : o(Error("Browser doesn't support triggering events"))
            }, d: function (n) {
                return c.la(n) ? n() : n
            }, Ua: function (n, t, i) {
                var u = (n.className || "").split(/\s+/), r = 0 <= c.a.j(u, t);
                if (i && !r)n.className += (u[0] ? " " : "") + t; else if (r && !i) {
                    for (i = "", r = 0; r < u.length; r++)u[r] != t && (i += u[r] + " ");
                    n.className = c.a.w(i)
                }
            }, Qa: function (n, t) {
                var i = c.a.d(t);
                (i === u || i === e) && (i = "");
                "innerText"in n ? n.innerText = i : n.textContent = i;
                9 <= s && (n.style.display = n.style.display)
            }, lb: function (n) {
                if (9 <= s) {
                    var t = n.style.width;
                    n.style.width = 0;
                    n.style.width = t
                }
            }, Eb: function (n, t) {
                for (var n = c.a.d(n), t = c.a.d(t), r = [], i = n; i <= t; i++)r.push(i);
                return r
            }, L: function (n) {
                for (var i = [], t = 0, r = n.length; t < r; t++)i.push(n[t]);
                return i
            }, tb: 6 === s, ub: 7 === s, ja: s, Da: function (n, t) {
                for (var r = c.a.L(n.getElementsByTagName("input")).concat(c.a.L(n.getElementsByTagName("textarea"))), f = "string" == typeof t ? function (n) {
                    return n.name === t
                } : function (n) {
                    return t.test(n.name)
                }, u = [], i = r.length - 1; 0 <= i; i--)f(r[i]) && u.push(r[i]);
                return u
            }, Bb: function (t) {
                return"string" == typeof t && (t = c.a.w(t)) ? n.JSON && n.JSON.parse ? n.JSON.parse(t) : new Function("return " + t)() : u
            }, sa: function (n, t, i) {
                return("undefined" == typeof JSON || "undefined" == typeof JSON.stringify) && o(Error("Cannot find JSON.stringify(). Some browsers (e.g., IE < 8) don't support it natively, but you can overcome this by adding a script reference to json2.js, downloadable from https://www.json.org/json2.js")), JSON.stringify(c.a.d(n), t, i)
            }, Cb: function (n, i, r) {
                var r = r || {}, h = r.params || {}, l = r.includeFields || this.Ca, a = n, o, s, e, i, u, f;
                if ("object" == typeof n && "form" === c.a.o(n))for (a = n.action, o = l.length - 1; 0 <= o; o--)for (s = c.a.Da(n, l[o]), e = s.length - 1; 0 <= e; e--)h[s[e].name] = s[e].value;
                i = c.a.d(i);
                u = t.createElement("form");
                u.style.display = "none";
                u.action = a;
                u.method = "post";
                for (f in i)n = t.createElement("input"), n.name = f, n.value = c.a.sa(c.a.d(i[f])), u.appendChild(n);
                for (f in h)n = t.createElement("input"), n.name = f, n.value = h[f], u.appendChild(n);
                t.body.appendChild(u);
                r.submitter ? r.submitter(u) : u.submit();
                setTimeout(function () {
                    u.parentNode.removeChild(u)
                }, 0)
            }}
        };
        c.b("utils", c.a);
        c.b("utils.arrayForEach", c.a.v);
        c.b("utils.arrayFirst", c.a.ab);
        c.b("utils.arrayFilter", c.a.aa);
        c.b("utils.arrayGetDistinctValues", c.a.za);
        c.b("utils.arrayIndexOf", c.a.j);
        c.b("utils.arrayMap", c.a.T);
        c.b("utils.arrayPushAll", c.a.N);
        c.b("utils.arrayRemoveItem", c.a.ba);
        c.b("utils.extend", c.a.extend);
        c.b("utils.fieldsIncludedWithJsonPost", c.a.Ca);
        c.b("utils.getFormFields", c.a.Da);
        c.b("utils.postJson", c.a.Cb);
        c.b("utils.parseJson", c.a.Bb);
        c.b("utils.registerEventHandler", c.a.n);
        c.b("utils.stringifyJson", c.a.sa);
        c.b("utils.range", c.a.Eb);
        c.b("utils.toggleDomNodeCssClass", c.a.Ua);
        c.b("utils.triggerEvent", c.a.va);
        c.b("utils.unwrapObservable", c.a.d);
        Function.prototype.bind || (Function.prototype.bind = function (n) {
            var i = this, t = Array.prototype.slice.call(arguments), n = t.shift();
            return function () {
                return i.apply(n, t.concat(Array.prototype.slice.call(arguments)))
            }
        });
        c.a.f = new function () {
            var i = 0, n = "__ko__" + (new Date).getTime(), t = {};
            return{get: function (n, t) {
                var i = c.a.f.getAll(n, f);
                return i === e ? e : i[t]
            }, set: function (n, t, i) {
                i === e && c.a.f.getAll(n, f) === e || (c.a.f.getAll(n, r)[t] = i)
            }, getAll: function (r, u) {
                var f = r[n];
                if (!(f && "null" !== f)) {
                    if (!u)return;
                    f = r[n] = "ko" + i++;
                    t[f] = {}
                }
                return t[f]
            }, clear: function (i) {
                var r = i[n];
                r && (delete t[r], i[n] = u)
            }}
        };
        c.b("utils.domData", c.a.f);
        c.b("utils.domData.clear", c.a.f.clear);
        c.a.G = new function () {
            function n(n, t) {
                var r = c.a.f.get(n, i);
                return r === e && t && (r = [], c.a.f.set(n, i, r)), r
            }

            function t(i) {
                var r = n(i, f), e;
                if (r)for (r = r.slice(0), e = 0; e < r.length; e++)r[e](i);
                if (c.a.f.clear(i), "function" == typeof jQuery && "function" == typeof jQuery.cleanData && jQuery.cleanData([i]), u[i.nodeType])for (r = i.firstChild; i = r;)r = i.nextSibling, 8 === i.nodeType && t(i)
            }

            var i = "__ko_domNodeDisposal__" + (new Date).getTime(), s = {1: r, 8: r, 9: r}, u = {1: r, 9: r};
            return{wa: function (t, i) {
                "function" != typeof i && o(Error("Callback must be a function"));
                n(t, r).push(i)
            }, Ma: function (t, r) {
                var u = n(t, f);
                u && (c.a.ba(u, r), 0 == u.length && c.a.f.set(t, i, e))
            }, F: function (n) {
                var i, n, r;
                if (s[n.nodeType] && (t(n), u[n.nodeType]))for (i = [], c.a.N(i, n.getElementsByTagName("*")), n = 0, r = i.length; n < r; n++)t(i[n])
            }, removeNode: function (n) {
                c.F(n);
                n.parentNode && n.parentNode.removeChild(n)
            }}
        };
        c.F = c.a.G.F;
        c.removeNode = c.a.G.removeNode;
        c.b("cleanNode", c.F);
        c.b("removeNode", c.removeNode);
        c.b("utils.domNodeDisposal", c.a.G);
        c.b("utils.domNodeDisposal.addDisposeCallback", c.a.G.wa);
        c.b("utils.domNodeDisposal.removeDisposeCallback", c.a.G.Ma), function () {
            c.a.pa = function (i) {
                var r, u;
                if ("undefined" != typeof jQuery) {
                    if ((r = jQuery.clean([i])) && r[0]) {
                        for (i = r[0]; i.parentNode && 11 !== i.parentNode.nodeType;)i = i.parentNode;
                        i.parentNode && i.parentNode.removeChild(i)
                    }
                } else {
                    for (u = c.a.w(i).toLowerCase(), r = t.createElement("div"), u = u.match(/^<(thead|tbody|tfoot)/) && [1, "<table>", "<\/table>"] || !u.indexOf("<tr") && [2, "<table><tbody>", "<\/tbody><\/table>"] || (!u.indexOf("<td") || !u.indexOf("<th")) && [3, "<table><tbody><tr>", "<\/tr><\/tbody><\/table>"] || [0, "", ""], i = "ignored<div>" + u[1] + i + u[2] + "<\/div>", "function" == typeof n.innerShiv ? r.appendChild(n.innerShiv(i)) : r.innerHTML = i; u[0]--;)r = r.lastChild;
                    r = c.a.L(r.lastChild.childNodes)
                }
                return r
            };
            c.a.Y = function (n, t) {
                if (c.a.ga(n), t !== u && t !== e)if ("string" != typeof t && (t = t.toString()), "undefined" != typeof jQuery)jQuery(n).html(t); else for (var r = c.a.pa(t), i = 0; i < r.length; i++)n.appendChild(r[i])
            }
        }();
        c.b("utils.parseHtmlFragment", c.a.pa);
        c.b("utils.setHtml", c.a.Y);
        c.s = function () {
            function t() {
                return(4294967296 * (1 + Math.random()) | 0).toString(16).substring(1)
            }

            function i(n, t) {
                var r;
                if (n)if (8 == n.nodeType)r = c.s.Ja(n.nodeValue), r != u && t.push({jb: n, yb: r}); else if (1 == n.nodeType)for (var r = 0, f = n.childNodes, e = f.length; r < e; r++)i(f[r], t)
            }

            var n = {};
            return{na: function (i) {
                "function" != typeof i && o(Error("You can only pass a function to ko.memoization.memoize()"));
                var r = t() + t();
                return n[r] = i, "<!--[ko_memo:" + r + "]-->"
            }, Va: function (t, i) {
                var f = n[t];
                f === e && o(Error("Couldn't find any memo with ID " + t + ". Perhaps it's already been unmemoized."));
                try {
                    return f.apply(u, i || []), r
                } finally {
                    delete n[t]
                }
            }, Wa: function (n, t) {
                var f = [], u, o, r, e;
                for (i(n, f), u = 0, o = f.length; u < o; u++)r = f[u].jb, e = [r], t && c.a.N(e, t), c.s.Va(f[u].yb, e), r.nodeValue = "", r.parentNode && r.parentNode.removeChild(r)
            }, Ja: function (n) {
                return(n = n.match(/^\[ko_memo\:(.*?)\]$/)) ? n[1] : u
            }}
        }();
        c.b("memoization", c.s);
        c.b("memoization.memoize", c.s.na);
        c.b("memoization.unmemoize", c.s.Va);
        c.b("memoization.parseMemoText", c.s.Ja);
        c.b("memoization.unmemoizeDomNodeAndDescendants", c.s.Wa);
        c.Ba = {throttle: function (n, t) {
            n.throttleEvaluation = t;
            var i = u;
            return c.h({read: n, write: function (r) {
                clearTimeout(i);
                i = setTimeout(function () {
                    n(r)
                }, t)
            }})
        }, notify: function (n, t) {
            return n.equalityComparer = "always" == t ? s(f) : c.m.fn.equalityComparer, n
        }};
        c.b("extenders", c.Ba);
        c.Sa = function (n, t, i) {
            this.target = n;
            this.ca = t;
            this.ib = i;
            c.B(this, "dispose", this.A)
        };
        c.Sa.prototype.A = function () {
            this.sb = r;
            this.ib()
        };
        c.R = function () {
            this.u = {};
            c.a.extend(this, c.R.fn);
            c.B(this, "subscribe", this.ta);
            c.B(this, "extend", this.extend);
            c.B(this, "getSubscriptionsCount", this.ob)
        };
        c.R.fn = {ta: function (n, t, i) {
            var i = i || "change", n = t ? n.bind(t) : n, r = new c.Sa(this, n, function () {
                c.a.ba(this.u[i], r)
            }.bind(this));
            return this.u[i] || (this.u[i] = []), this.u[i].push(r), r
        }, notifySubscribers: function (n, t) {
            t = t || "change";
            this.u[t] && c.a.v(this.u[t].slice(0), function (t) {
                t && t.sb !== r && t.ca(n)
            })
        }, ob: function () {
            var n = 0;
            for (var t in this.u)this.u.hasOwnProperty(t) && (n += this.u[t].length);
            return n
        }, extend: function (n) {
            var t = this, i, r;
            if (n)for (i in n)r = c.Ba[i], "function" == typeof r && (t = r(t, n[i]));
            return t
        }};
        c.Ga = function (n) {
            return"function" == typeof n.ta && "function" == typeof n.notifySubscribers
        };
        c.b("subscribable", c.R);
        c.b("isSubscribable", c.Ga);
        c.U = function () {
            var n = [];
            return{bb: function (t) {
                n.push({ca: t, Aa: []})
            }, end: function () {
                n.pop()
            }, La: function (t) {
                if (c.Ga(t) || o(Error("Only subscribable things can act as dependencies")), 0 < n.length) {
                    var i = n[n.length - 1];
                    0 <= c.a.j(i.Aa, t) || (i.Aa.push(t), i.ca(t))
                }
            }}
        }();
        y = {undefined: r, boolean: r, number: r, string: r};
        c.m = function (n) {
            function t() {
                return 0 < arguments.length ? (t.equalityComparer && t.equalityComparer(i, arguments[0]) || (t.I(), i = arguments[0], t.H()), this) : (c.U.La(t), i)
            }

            var i = n;
            return c.R.call(t), t.H = function () {
                t.notifySubscribers(i)
            }, t.I = function () {
                t.notifySubscribers(i, "beforeChange")
            }, c.a.extend(t, c.m.fn), c.B(t, "valueHasMutated", t.H), c.B(t, "valueWillMutate", t.I), t
        };
        c.m.fn = {equalityComparer: function (n, t) {
            return n === u || typeof n in y ? n === t : f
        }};
        l = c.m.Db = "__ko_proto__";
        c.m.fn[l] = c.m;
        c.ia = function (n, t) {
            return n === u || n === e || n[l] === e ? f : n[l] === t ? r : c.ia(n[l], t)
        };
        c.la = function (n) {
            return c.ia(n, c.m)
        };
        c.Ha = function (n) {
            return"function" == typeof n && n[l] === c.m || "function" == typeof n && n[l] === c.h && n.pb ? r : f
        };
        c.b("observable", c.m);
        c.b("isObservable", c.la);
        c.b("isWriteableObservable", c.Ha);
        c.Q = function (n) {
            0 == arguments.length && (n = []);
            n === u || n === e || "length"in n || o(Error("The argument passed when initializing an observable array must be an array, or null, or undefined."));
            var t = c.m(n);
            return c.a.extend(t, c.Q.fn), t
        };
        c.Q.fn = {remove: function (n) {
            for (var u, r = this(), i = [], f = "function" == typeof n ? n : function (t) {
                return t === n
            }, t = 0; t < r.length; t++)u = r[t], f(u) && (0 === i.length && this.I(), i.push(u), r.splice(t, 1), t--);
            return i.length && this.H(), i
        }, removeAll: function (n) {
            if (n === e) {
                var t = this(), i = t.slice(0);
                return this.I(), t.splice(0, t.length), this.H(), i
            }
            return n ? this.remove(function (t) {
                return 0 <= c.a.j(n, t)
            }) : []
        }, destroy: function (n) {
            var i = this(), u = "function" == typeof n ? n : function (t) {
                return t === n
            }, t;
            for (this.I(), t = i.length - 1; 0 <= t; t--)u(i[t]) && (i[t]._destroy = r);
            this.H()
        }, destroyAll: function (n) {
            return n === e ? this.destroy(s(r)) : n ? this.destroy(function (t) {
                return 0 <= c.a.j(n, t)
            }) : []
        }, indexOf: function (n) {
            var t = this();
            return c.a.j(t, n)
        }, replace: function (n, t) {
            var i = this.indexOf(n);
            0 <= i && (this.I(), this()[i] = t, this.H())
        }};
        c.a.v("pop push reverse shift sort splice unshift".split(" "), function (n) {
            c.Q.fn[n] = function () {
                var t = this();
                return this.I(), t = t[n].apply(t, arguments), this.H(), t
            }
        });
        c.a.v(["slice"], function (n) {
            c.Q.fn[n] = function () {
                var t = this();
                return t[n].apply(t, arguments)
            }
        });
        c.b("observableArray", c.Q);
        c.h = function (n, t, i) {
            function tt() {
                c.a.v(a, function (n) {
                    n.A()
                });
                a = []
            }

            function rt() {
                var n = h.throttleEvaluation;
                n && 0 <= n ? (clearTimeout(nt), nt = setTimeout(v, n)) : v()
            }

            function v() {
                var n, u, i;
                if (!k)if (b && g())p(); else {
                    k = r;
                    try {
                        for (n = c.a.T(a, function (n) {
                            return n.target
                        }), c.U.bb(function (t) {
                            var i;
                            0 <= (i = c.a.j(n, t)) ? n[i] = e : a.push(t.ta(rt))
                        }), u = l.call(t), i = n.length - 1; 0 <= i; i--)n[i] && a.splice(i, 1)[0].A();
                        b = r;
                        h.notifySubscribers(y, "beforeChange");
                        y = u
                    } finally {
                        c.U.end()
                    }
                    h.notifySubscribers(y);
                    k = f
                }
            }

            function h() {
                if (0 < arguments.length)ut.apply(h, arguments); else return b || v(), c.U.La(h), y
            }

            function ut() {
                "function" == typeof d ? d.apply(t, arguments) : o(Error("Cannot write a value to a ko.computed unless you specify a 'write' option. If you wish to read the current value, don't pass any parameters."))
            }

            var y, b = f, k = f, l = n, d, it, g, nt;
            l && "object" == typeof l ? (i = l, l = i.read) : (i = i || {}, l || (l = i.read));
            "function" != typeof l && o(Error("Pass a function that returns the value of the ko.computed"));
            d = i.write;
            t || (t = i.owner);
            var a = [], p = tt, w = "object" == typeof i.disposeWhenNodeIsRemoved ? i.disposeWhenNodeIsRemoved : u, g = i.disposeWhen || s(f);
            return w && (p = function () {
                c.a.G.Ma(w, arguments.callee);
                tt()
            }, c.a.G.wa(w, p), it = g, g = function () {
                return!c.a.fa(w) || it()
            }), nt = u, h.nb = function () {
                return a.length
            }, h.pb = "function" == typeof i.write, h.A = function () {
                p()
            }, c.R.call(h), c.a.extend(h, c.h.fn), i.deferEvaluation !== r && v(), c.B(h, "dispose", h.A), c.B(h, "getDependenciesCount", h.nb), h
        };
        c.rb = function (n) {
            return c.ia(n, c.h)
        };
        h = c.m.Db;
        c.h[h] = c.m;
        c.h.fn = {};
        c.h.fn[h] = c.h;
        c.b("dependentObservable", c.h);
        c.b("computed", c.h);
        c.b("isComputed", c.rb), function () {
            function n(r, f, o) {
                if (o = o || new i, r = f(r), !("object" == typeof r && r !== u && r !== e && !(r instanceof Date)))return r;
                var s = r instanceof Array ? [] : {};
                return o.save(r, s), t(r, function (t) {
                    var i = f(r[t]), u;
                    switch (typeof i) {
                        case"boolean":
                        case"number":
                        case"string":
                        case"function":
                            s[t] = i;
                            break;
                        case"object":
                        case"undefined":
                            u = o.get(i);
                            s[t] = u !== e ? u : n(i, f, o)
                    }
                }), s
            }

            function t(n, t) {
                if (n instanceof Array) {
                    for (var i = 0; i < n.length; i++)t(i);
                    "function" == typeof n.toJSON && t("toJSON")
                } else for (i in n)t(i)
            }

            function i() {
                var n = [], t = [];
                this.save = function (i, r) {
                    var u = c.a.j(n, i);
                    0 <= u ? t[u] = r : (n.push(i), t.push(r))
                };
                this.get = function (i) {
                    return i = c.a.j(n, i), 0 <= i ? t[i] : e
                }
            }

            c.Ta = function (t) {
                return 0 == arguments.length && o(Error("When calling ko.toJS, pass the object you want to convert.")), n(t, function (n) {
                    for (var t = 0; c.la(n) && 10 > t; t++)n = n();
                    return n
                })
            };
            c.toJSON = function (n, t, i) {
                return n = c.Ta(n), c.a.sa(n, t, i)
            }
        }();
        c.b("toJS", c.Ta);
        c.b("toJSON", c.toJSON), function () {
            c.k = {r: function (n) {
                switch (c.a.o(n)) {
                    case"option":
                        return n.__ko__hasDomDataOptionValue__ === r ? c.a.f.get(n, c.c.options.oa) : n.getAttribute("value");
                    case"select":
                        return 0 <= n.selectedIndex ? c.k.r(n.options[n.selectedIndex]) : e;
                    default:
                        return n.value
                }
            }, S: function (n, t) {
                switch (c.a.o(n)) {
                    case"option":
                        switch (typeof t) {
                            case"string":
                                c.a.f.set(n, c.c.options.oa, e);
                                "__ko__hasDomDataOptionValue__"in n && delete n.__ko__hasDomDataOptionValue__;
                                n.value = t;
                                break;
                            default:
                                c.a.f.set(n, c.c.options.oa, t);
                                n.__ko__hasDomDataOptionValue__ = r;
                                n.value = "number" == typeof t ? t : ""
                        }
                        break;
                    case"select":
                        for (var i = n.options.length - 1; 0 <= i; i--)if (c.k.r(n.options[i]) == t) {
                            n.selectedIndex = i;
                            break
                        }
                        break;
                    default:
                        (t === u || t === e) && (t = "");
                        n.value = t
                }
            }}
        }();
        c.b("selectExtensions", c.k);
        c.b("selectExtensions.readValue", c.k.r);
        c.b("selectExtensions.writeValue", c.k.S);
        c.g = function () {
            function n(n, i) {
                for (var r = u; n != r;)r = n, n = n.replace(t, function (n, t) {
                    return i[t]
                });
                return n
            }

            var t = /\@ko_token_(\d+)\@/g, i = /^[\_$a-z][\_$a-z0-9]*(\[.*?\])*(\.[\_$a-z][\_$a-z0-9]*(\[.*?\])*)*$/i, e = ["true", "false"];
            return{D: [], W: function (t) {
                var i = c.a.w(t), f;
                if (3 > i.length)return[];
                "{" === i.charAt(0) && (i = i.substring(1, i.length - 1));
                for (var t = [], e = u, o, r = 0; r < i.length; r++)if (f = i.charAt(r), e === u)switch (f) {
                    case'"':
                    case"'":
                    case"/":
                        e = r;
                        o = f
                } else if (f == o && "\\" !== i.charAt(r - 1)) {
                    f = i.substring(e, r + 1);
                    t.push(f);
                    var l = "@ko_token_" + (t.length - 1) + "@", i = i.substring(0, e) + l + i.substring(r + 1), r = r - (f.length - l.length), e = u
                }
                o = e = u;
                for (var s = 0, h = u, r = 0; r < i.length; r++) {
                    if (f = i.charAt(r), e === u)switch (f) {
                        case"{":
                            e = r;
                            h = f;
                            o = "}";
                            break;
                        case"(":
                            e = r;
                            h = f;
                            o = ")";
                            break;
                        case"[":
                            e = r;
                            h = f;
                            o = "]"
                    }
                    f === h ? s++ : f === o && (s--, 0 === s && (f = i.substring(e, r + 1), t.push(f), l = "@ko_token_" + (t.length - 1) + "@", i = i.substring(0, e) + l + i.substring(r + 1), r -= f.length - l.length, e = u))
                }
                for (o = [], i = i.split(","), e = 0, r = i.length; e < r; e++)s = i[e], h = s.indexOf(":"), 0 < h && h < s.length - 1 ? (f = s.substring(h + 1), o.push({key: n(s.substring(0, h), t), value: n(f, t)})) : o.push({unknown: n(s, t)});
                return o
            }, ka: function (n) {
                for (var s, f, o = "string" == typeof n ? c.g.W(n) : n, r = [], n = [], t, h = 0; t = o[h]; h++)if (0 < r.length && r.push(","), t.key) {
                    n:{
                        s = t.key;
                        f = c.a.w(s);
                        switch (f.length && f.charAt(0)) {
                            case"'":
                            case'"':
                                break n;
                            default:
                                s = "'" + f + "'"
                        }
                    }
                    t = t.value;
                    r.push(s);
                    r.push(":");
                    r.push(t);
                    f = c.a.w(t);
                    (0 <= c.a.j(e, c.a.w(f).toLowerCase()) ? 0 : f.match(i) !== u) && (0 < n.length && n.push(", "), n.push(s + " : function(__ko_value) { " + t + " = __ko_value; }"))
                } else t.unknown && r.push(t.unknown);
                return o = r.join(""), 0 < n.length && (o = o + ", '_ko_property_writers' : { " + n.join("") + " } "), o
            }, wb: function (n, t) {
                for (var i = 0; i < n.length; i++)if (c.a.w(n[i].key) == t)return r;
                return f
            }, $: function (n, t, i, r, u) {
                n && c.Ha(n) ? u && n() === r || n(r) : (n = t()._ko_property_writers) && n[i] && n[i](r)
            }}
        }();
        c.b("jsonExpressionRewriting", c.g);
        c.b("jsonExpressionRewriting.bindingRewriteValidators", c.g.D);
        c.b("jsonExpressionRewriting.parseObjectLiteral", c.g.W);
        c.b("jsonExpressionRewriting.insertPropertyAccessorsIntoJson", c.g.ka), function () {
            function n(n) {
                return 8 == n.nodeType && (f ? n.text : n.nodeValue).match(h)
            }

            function i(n) {
                return 8 == n.nodeType && (f ? n.text : n.nodeValue).match(l)
            }

            function e(t, r) {
                for (var f = t, e = 1, s = []; f = f.nextSibling;) {
                    if (i(f) && (e--, 0 === e))return s;
                    s.push(f);
                    n(f) && e++
                }
                return r || o(Error("Cannot find closing comment tag to match: " + t.nodeValue)), u
            }

            function s(n, t) {
                var i = e(n, t);
                return i ? 0 < i.length ? i[i.length - 1].nextSibling : n.nextSibling : u
            }

            var f = "<!--test-->" === t.createComment("test").text, h = f ? /^<\!--\s*ko\s+(.*\:.*)\s*--\>$/ : /^\s*ko\s+(.*\:.*)\s*$/, l = f ? /^<\!--\s*\/ko\s*--\>$/ : /^\s*\/ko\s*$/, a = {ul: r, ol: r};
            c.e = {C: {}, childNodes: function (t) {
                return n(t) ? e(t) : t.childNodes
            }, ha: function (t) {
                if (n(t))for (var t = c.e.childNodes(t), i = 0, r = t.length; i < r; i++)c.removeNode(t[i]); else c.a.ga(t)
            }, X: function (t, i) {
                if (n(t)) {
                    c.e.ha(t);
                    for (var u = t.nextSibling, r = 0, f = i.length; r < f; r++)u.parentNode.insertBefore(i[r], u)
                } else c.a.X(t, i)
            }, Ka: function (t, i) {
                n(t) ? t.parentNode.insertBefore(i, t.nextSibling) : t.firstChild ? t.insertBefore(i, t.firstChild) : t.appendChild(i)
            }, Fa: function (t, i, r) {
                n(t) ? t.parentNode.insertBefore(i, r.nextSibling) : r.nextSibling ? t.insertBefore(i, r.nextSibling) : t.appendChild(i)
            }, firstChild: function (t) {
                return n(t) ? !t.nextSibling || i(t.nextSibling) ? u : t.nextSibling : t.firstChild
            }, nextSibling: function (t) {
                return n(t) && (t = s(t)), t.nextSibling && i(t.nextSibling) ? u : t.nextSibling
            }, Xa: function (t) {
                return(t = n(t)) ? t[1] : u
            }, Ia: function (t) {
                var h, f, e, o;
                if (a[c.a.o(t)] && (h = t.firstChild, h))do if (1 === h.nodeType) {
                    if (f = h.firstChild, e = u, f)do e ? e.push(f) : n(f) ? (o = s(f, r), o ? f = o : e = [f]) : i(f) && (e = [f]); while (f = f.nextSibling);
                    if (f = e)for (e = h.nextSibling, o = 0; o < f.length; o++)e ? t.insertBefore(f[o], e) : t.appendChild(f[o])
                } while (h = h.nextSibling)
            }}
        }();
        c.b("virtualElements", c.e);
        c.b("virtualElements.allowedBindings", c.e.C);
        c.b("virtualElements.emptyNode", c.e.ha);
        c.b("virtualElements.insertAfter", c.e.Fa);
        c.b("virtualElements.prepend", c.e.Ka);
        c.b("virtualElements.setDomNodeChildren", c.e.X), function () {
            c.J = function () {
                this.cb = {}
            };
            c.a.extend(c.J.prototype, {nodeHasBindings: function (n) {
                switch (n.nodeType) {
                    case 1:
                        return n.getAttribute("data-bind") != u;
                    case 8:
                        return c.e.Xa(n) != u;
                    default:
                        return f
                }
            }, getBindings: function (n, t) {
                var i = this.getBindingsString(n, t);
                return i ? this.parseBindingsString(i, t) : u
            }, getBindingsString: function (n) {
                switch (n.nodeType) {
                    case 1:
                        return n.getAttribute("data-bind");
                    case 8:
                        return c.e.Xa(n);
                    default:
                        return u
                }
            }, parseBindingsString: function (n, t) {
                var h;
                try {
                    var i = t.$data, i = "object" == typeof i && i != u ? [i, t] : [t], f = i.length, e = this.cb, s = f + "_" + n, r;
                    return(r = e[s]) || (h = " { " + c.g.ka(n) + " } ", r = e[s] = c.a.eb(h, f)), r(i)
                } catch (l) {
                    o(Error("Unable to parse bindings.\nMessage: " + l + ";\nBindings value: " + n))
                }
            }});
            c.J.instance = new c.J
        }();
        c.b("bindingProvider", c.J), function () {
            function t(n, t, r) {
                for (var u = c.e.firstChild(t); t = u;)u = c.e.nextSibling(t), i(n, t, r)
            }

            function i(n, i, e) {
                var s = r, o = 1 === i.nodeType;
                o && c.e.Ia(i);
                (o && e || c.J.instance.nodeHasBindings(i)) && (s = f(i, u, n, e).Gb);
                s && t(n, i, !o)
            }

            function f(n, t, i, r) {
                function l(n) {
                    return function () {
                        return f[n]
                    }
                }

                function a() {
                    return f
                }

                var s = 0, f, h;
                return c.h(function () {
                    var y = i && i instanceof c.z ? i : new c.z(c.a.d(i)), p = y.$data, u, v;
                    if (r && c.Ra(n, y), f = ("function" == typeof t ? t() : t) || c.J.instance.getBindings(n, y)) {
                        if (0 === s) {
                            s = 1;
                            for (u in f)v = c.c[u], v && 8 === n.nodeType && !c.e.C[u] && o(Error("The binding '" + u + "' cannot be used with virtual elements")), v && "function" == typeof v.init && (v = v.init(n, l(u), a, p, y)) && v.controlsDescendantBindings && (h !== e && o(Error("Multiple bindings (" + h + " and " + u + ") are trying to control descendant bindings of the same element. You cannot use these bindings together on the same element.")), h = u);
                            s = 2
                        }
                        if (2 === s)for (u in f)(v = c.c[u]) && "function" == typeof v.update && v.update(n, l(u), a, p, y)
                    }
                }, u, {disposeWhenNodeIsRemoved: n}), {Gb: h === e}
            }

            c.c = {};
            c.z = function (n, t) {
                t ? (c.a.extend(this, t), this.$parentContext = t, this.$parent = t.$data, this.$parents = (t.$parents || []).slice(0), this.$parents.unshift(this.$parent)) : (this.$parents = [], this.$root = n);
                this.$data = n
            };
            c.z.prototype.createChildContext = function (n) {
                return new c.z(n, this)
            };
            c.z.prototype.extend = function (n) {
                var t = c.a.extend(new c.z, this);
                return c.a.extend(t, n)
            };
            c.Ra = function (n, t) {
                if (2 == arguments.length)c.a.f.set(n, "__ko_bindingContext__", t); else return c.a.f.get(n, "__ko_bindingContext__")
            };
            c.ya = function (n, t, i) {
                return 1 === n.nodeType && c.e.Ia(n), f(n, t, i, r)
            };
            c.Ya = function (n, i) {
                (1 === i.nodeType || 8 === i.nodeType) && t(n, i, r)
            };
            c.xa = function (t, u) {
                u && 1 !== u.nodeType && 8 !== u.nodeType && o(Error("ko.applyBindings: first parameter should be your view model; second parameter should be a DOM node"));
                u = u || n.document.body;
                i(t, u, r)
            };
            c.ea = function (n) {
                switch (n.nodeType) {
                    case 1:
                    case 8:
                        var t = c.Ra(n);
                        if (t)return t;
                        if (n.parentNode)return c.ea(n.parentNode)
                }
            };
            c.hb = function (n) {
                return(n = c.ea(n)) ? n.$data : e
            };
            c.b("bindingHandlers", c.c);
            c.b("applyBindings", c.xa);
            c.b("applyBindingsToDescendants", c.Ya);
            c.b("applyBindingsToNode", c.ya);
            c.b("contextFor", c.ea);
            c.b("dataFor", c.hb)
        }();
        c.a.v(["click"], function (n) {
            c.c[n] = {init: function (t, i, r, u) {
                return c.c.event.init.call(this, t, function () {
                    var t = {};
                    return t[n] = i(), t
                }, r, u)
            }}
        });
        c.c.event = {init: function (n, t, i, u) {
            var e = t() || {};
            for (var o in e)(function () {
                var e = o;
                "string" == typeof e && c.a.n(n, e, function (n) {
                    var s, h = t()[e], l, o;
                    if (h) {
                        l = i();
                        try {
                            o = c.a.L(arguments);
                            o.unshift(u);
                            s = h.apply(u, o)
                        } finally {
                            s !== r && (n.preventDefault ? n.preventDefault() : n.returnValue = f)
                        }
                        l[e + "Bubble"] === f && (n.cancelBubble = r, n.stopPropagation && n.stopPropagation())
                    }
                })
            })()
        }};
        c.c.submit = {init: function (n, t, i, u) {
            "function" != typeof t() && o(Error("The value for a submit binding must be a function"));
            c.a.n(n, "submit", function (i) {
                var e, o = t();
                try {
                    e = o.call(u, n)
                } finally {
                    e !== r && (i.preventDefault ? i.preventDefault() : i.returnValue = f)
                }
            })
        }};
        c.c.visible = {update: function (n, t) {
            var i = c.a.d(t()), r = "none" != n.style.display;
            i && !r ? n.style.display = "" : !i && r && (n.style.display = "none")
        }};
        c.c.enable = {update: function (n, t) {
            var i = c.a.d(t());
            i && n.disabled ? n.removeAttribute("disabled") : !i && !n.disabled && (n.disabled = r)
        }};
        c.c.disable = {update: function (n, t) {
            c.c.enable.update(n, function () {
                return!c.a.d(t())
            })
        }};
        c.c.value = {init: function (n, t, i) {
            function s() {
                var u = t(), f = c.k.r(n);
                c.g.$(u, i, "value", f, r)
            }

            var u = ["change"], e = i().valueUpdate, o;
            e && ("string" == typeof e && (e = [e]), c.a.N(u, e), u = c.a.za(u));
            c.a.ja && "input" == n.tagName.toLowerCase() && "text" == n.type && "off" != n.autocomplete && (!n.form || "off" != n.form.autocomplete) && -1 == c.a.j(u, "propertychange") && (o = f, c.a.n(n, "propertychange", function () {
                o = r
            }), c.a.n(n, "blur", function () {
                o && (o = f, s())
            }));
            c.a.v(u, function (t) {
                var i = s;
                c.a.Hb(t, "after") && (i = function () {
                    setTimeout(s, 0)
                }, t = t.substring(5));
                c.a.n(n, t, i)
            })
        }, update: function (n, t) {
            var e = "select" === c.a.o(n), u = c.a.d(t()), i = c.k.r(n), o = u != i;
            0 === u && 0 !== i && "0" !== i && (o = r);
            o && (i = function () {
                c.k.S(n, u)
            }, i(), e && setTimeout(i, 0));
            e && 0 < n.length && v(n, u, f)
        }};
        c.c.options = {update: function (n, i, f) {
            var h, i, y, a, l;
            "select" !== c.a.o(n) && o(Error("options binding applies only to SELECT elements"));
            for (var p = 0 == n.length, w = c.a.T(c.a.aa(n.childNodes, function (n) {
                return n.tagName && "option" === c.a.o(n) && n.selected
            }), function (n) {
                return c.k.r(n) || n.innerText || n.textContent
            }), b = n.scrollTop, s = c.a.d(i()); 0 < n.length;)c.F(n.options[0]), n.remove(0);
            if (s) {
                for (f = f(), "number" != typeof s.length && (s = [s]), f.optionsCaption && (h = t.createElement("option"), c.a.Y(h, f.optionsCaption), c.k.S(h, e), n.appendChild(h)), i = 0, y = s.length; i < y; i++) {
                    var h = t.createElement("option"), l = "string" == typeof f.optionsValue ? s[i][f.optionsValue] : s[i], l = c.a.d(l);
                    c.k.S(h, l);
                    a = f.optionsText;
                    l = "function" == typeof a ? a(s[i]) : "string" == typeof a ? s[i][a] : l;
                    (l === u || l === e) && (l = "");
                    c.a.Qa(h, l);
                    n.appendChild(h)
                }
                for (s = n.getElementsByTagName("option"), i = h = 0, y = s.length; i < y; i++)0 <= c.a.j(w, c.k.r(s[i])) && (c.a.Pa(s[i], r), h++);
                n.scrollTop = b;
                p && "value"in f && v(n, c.a.d(f.value), r);
                c.a.lb(n)
            }
        }};
        c.c.options.oa = "__ko.optionValueDomData__";
        c.c.selectedOptions = {Ea: function (n) {
            for (var t, u, i = [], n = n.childNodes, r = 0, f = n.length; r < f; r++)t = n[r], u = c.a.o(t), "option" == u && t.selected ? i.push(c.k.r(t)) : "optgroup" == u && (t = c.c.selectedOptions.Ea(t), Array.prototype.splice.apply(i, [i.length, 0].concat(t)));
            return i
        }, init: function (n, t, i) {
            c.a.n(n, "change", function () {
                var n = t(), r = c.c.selectedOptions.Ea(this);
                c.g.$(n, i, "value", r)
            })
        }, update: function (n, t) {
            var i, r;
            if ("select" != c.a.o(n) && o(Error("values binding applies only to SELECT elements")), i = c.a.d(t()), i && "number" == typeof i.length)for (var f = n.childNodes, u = 0, e = f.length; u < e; u++)r = f[u], "option" === c.a.o(r) && c.a.Pa(r, 0 <= c.a.j(i, c.k.r(r)))
        }};
        c.c.text = {update: function (n, t) {
            c.a.Qa(n, t())
        }};
        c.c.html = {init: function () {
            return{controlsDescendantBindings: r}
        }, update: function (n, t) {
            var i = c.a.d(t());
            c.a.Y(n, i)
        }};
        c.c.css = {update: function (n, t) {
            var r = c.a.d(t() || {}), i, u;
            for (i in r)"string" == typeof i && (u = c.a.d(r[i]), c.a.Ua(n, i, u))
        }};
        c.c.style = {update: function (n, t) {
            var r = c.a.d(t() || {}), i, u;
            for (i in r)"string" == typeof i && (u = c.a.d(r[i]), n.style[i] = u || "")
        }};
        c.c.uniqueName = {init: function (n, i) {
            i() && (n.name = "ko_unique_" + ++c.c.uniqueName.gb, (c.a.tb || c.a.ub) && n.mergeAttributes(t.createElement("<input name='" + n.name + "'/>"), f))
        }};
        c.c.uniqueName.gb = 0;
        c.c.checked = {init: function (n, t, i) {
            c.a.n(n, "click", function () {
                var u, f;
                if ("checkbox" == n.type)u = n.checked; else if ("radio" == n.type && n.checked)u = n.value; else return;
                f = t();
                "checkbox" == n.type && c.a.d(f)instanceof Array ? (u = c.a.j(c.a.d(f), n.value), n.checked && 0 > u ? f.push(n.value) : !n.checked && 0 <= u && f.splice(u, 1)) : c.g.$(f, i, "checked", u, r)
            });
            "radio" != n.type || n.name || c.c.uniqueName.init(n, s(r))
        }, update: function (n, t) {
            var i = c.a.d(t());
            "checkbox" == n.type ? n.checked = i instanceof Array ? 0 <= c.a.j(i, n.value) : i : "radio" == n.type && (n.checked = n.value == i)
        }};
        a = {"class": "className", "for": "htmlFor"};
        c.c.attr = {update: function (n, t) {
            var s = c.a.d(t()) || {}, i, r, o;
            for (i in s)"string" == typeof i && (r = c.a.d(s[i]), o = r === f || r === u || r === e, o && n.removeAttribute(i), 8 >= c.a.ja && i in a ? (i = a[i], o ? n.removeAttribute(i) : n[i] = r) : o || n.setAttribute(i, r.toString()))
        }};
        c.c.hasfocus = {init: function (n, t, i) {
            function u(n) {
                var u = t();
                c.g.$(u, i, "hasfocus", n, r)
            }

            c.a.n(n, "focus", function () {
                u(r)
            });
            c.a.n(n, "focusin", function () {
                u(r)
            });
            c.a.n(n, "blur", function () {
                u(f)
            });
            c.a.n(n, "focusout", function () {
                u(f)
            })
        }, update: function (n, t) {
            var i = c.a.d(t());
            i ? n.focus() : n.blur();
            c.a.va(n, i ? "focusin" : "focusout")
        }};
        c.c["with"] = {p: function (n) {
            return function () {
                var t = n();
                return{"if": t, data: t, templateEngine: c.q.K}
            }
        }, init: function (n, t) {
            return c.c.template.init(n, c.c["with"].p(t))
        }, update: function (n, t, i, r, u) {
            return c.c.template.update(n, c.c["with"].p(t), i, r, u)
        }};
        c.g.D["with"] = f;
        c.e.C["with"] = r;
        c.c["if"] = {p: function (n) {
            return function () {
                return{"if": n(), templateEngine: c.q.K}
            }
        }, init: function (n, t) {
            return c.c.template.init(n, c.c["if"].p(t))
        }, update: function (n, t, i, r, u) {
            return c.c.template.update(n, c.c["if"].p(t), i, r, u)
        }};
        c.g.D["if"] = f;
        c.e.C["if"] = r;
        c.c.ifnot = {p: function (n) {
            return function () {
                return{ifnot: n(), templateEngine: c.q.K}
            }
        }, init: function (n, t) {
            return c.c.template.init(n, c.c.ifnot.p(t))
        }, update: function (n, t, i, r, u) {
            return c.c.template.update(n, c.c.ifnot.p(t), i, r, u)
        }};
        c.g.D.ifnot = f;
        c.e.C.ifnot = r;
        c.c.foreach = {p: function (n) {
            return function () {
                var t = c.a.d(n());
                return!t || "number" == typeof t.length ? {foreach: t, templateEngine: c.q.K} : {foreach: t.data, includeDestroyed: t.includeDestroyed, afterAdd: t.afterAdd, beforeRemove: t.beforeRemove, afterRender: t.afterRender, templateEngine: c.q.K}
            }
        }, init: function (n, t) {
            return c.c.template.init(n, c.c.foreach.p(t))
        }, update: function (n, t, i, r, u) {
            return c.c.template.update(n, c.c.foreach.p(t), i, r, u)
        }};
        c.g.D.foreach = f;
        c.e.C.foreach = r;
        c.t = function () {
        };
        c.t.prototype.renderTemplateSource = function () {
            o(Error("Override renderTemplateSource"))
        };
        c.t.prototype.createJavaScriptEvaluatorBlock = function () {
            o(Error("Override createJavaScriptEvaluatorBlock"))
        };
        c.t.prototype.makeTemplateSource = function (n, i) {
            if ("string" == typeof n) {
                var i = i || t, r = i.getElementById(n);
                return r || o(Error("Cannot find template with ID " + n)), new c.l.i(r)
            }
            if (1 == n.nodeType || 8 == n.nodeType)return new c.l.M(n);
            o(Error("Unknown template type: " + n))
        };
        c.t.prototype.renderTemplate = function (n, t, i, r) {
            return this.renderTemplateSource(this.makeTemplateSource(n, r), t, i)
        };
        c.t.prototype.isTemplateRewritten = function (n, i) {
            return this.allowTemplateRewriting === f || !(i && i != t) && this.V && this.V[n] ? r : this.makeTemplateSource(n, i).data("isRewritten")
        };
        c.t.prototype.rewriteTemplate = function (n, i, u) {
            var f = this.makeTemplateSource(n, u), i = i(f.text());
            f.text(i);
            f.data("isRewritten", r);
            u && u != t || "string" != typeof n || (this.V = this.V || {}, this.V[n] = r)
        };
        c.b("templateEngine", c.t);
        c.Z = function () {
            function n(n, t, i) {
                for (var r, f, n = c.g.W(n), e = c.g.D, u = 0; u < n.length; u++)r = n[u].key, e.hasOwnProperty(r) && (f = e[r], "function" == typeof f ? (r = f(n[u].value)) && o(Error(r)) : f || o(Error("This template engine does not support the '" + r + "' binding within its templates")));
                return n = "ko.templateRewriting.applyMemoizedBindingsToNextSibling(function() {             return (function() { return { " + c.g.ka(n) + " } })()         })", i.createJavaScriptEvaluatorBlock(n) + t
            }

            var t = /(<[a-z]+\d*(\s+(?!data-bind=)[a-z0-9\-]+(=(\"[^\"]*\"|\'[^\']*\'))?)*\s+)data-bind=(["'])([\s\S]*?)\5/gi, i = /<\!--\s*ko\b\s*([\s\S]*?)\s*--\>/g;
            return{mb: function (n, t, i) {
                t.isTemplateRewritten(n, i) || t.rewriteTemplate(n, function (n) {
                    return c.Z.zb(n, t)
                }, i)
            }, zb: function (r, u) {
                return r.replace(t, function (t, i, r, f, e, o, s) {
                    return n(s, i, u)
                }).replace(i, function (t, i) {
                    return n(i, "<!-- ko -->", u)
                })
            }, Za: function (n) {
                return c.s.na(function (t, i) {
                    t.nextSibling && c.ya(t.nextSibling, n, i)
                })
            }}
        }();
        c.b("templateRewriting", c.Z);
        c.b("templateRewriting.applyMemoizedBindingsToNextSibling", c.Z.Za), function () {
            c.l = {};
            c.l.i = function (n) {
                this.i = n
            };
            c.l.i.prototype.text = function () {
                var n = c.a.o(this.i), n = "script" === n ? "text" : "textarea" === n ? "value" : "innerHTML", t;
                if (0 == arguments.length)return this.i[n];
                t = arguments[0];
                "innerHTML" === n ? c.a.Y(this.i, t) : this.i[n] = t
            };
            c.l.i.prototype.data = function (n) {
                if (1 === arguments.length)return c.a.f.get(this.i, "templateSourceData_" + n);
                c.a.f.set(this.i, "templateSourceData_" + n, arguments[1])
            };
            c.l.M = function (n) {
                this.i = n
            };
            c.l.M.prototype = new c.l.i;
            c.l.M.prototype.text = function () {
                if (0 == arguments.length) {
                    var n = c.a.f.get(this.i, "__ko_anon_template__") || {};
                    return n.ua === e && n.da && (n.ua = n.da.innerHTML), n.ua
                }
                c.a.f.set(this.i, "__ko_anon_template__", {ua: arguments[0]})
            };
            c.l.i.prototype.nodes = function () {
                if (0 == arguments.length)return(c.a.f.get(this.i, "__ko_anon_template__") || {}).da;
                c.a.f.set(this.i, "__ko_anon_template__", {da: arguments[0]})
            };
            c.b("templateSources", c.l);
            c.b("templateSources.domElement", c.l.i);
            c.b("templateSources.anonymousTemplate", c.l.M)
        }(), function () {
            function i(n, t, i) {
                for (var r, t = c.e.nextSibling(t); n && (r = n) !== t;)n = c.e.nextSibling(r), (1 === r.nodeType || 8 === r.nodeType) && i(r)
            }

            function s(n, t) {
                if (n.length) {
                    var r = n[0], u = n[n.length - 1];
                    i(r, u, function (n) {
                        c.xa(t, n)
                    });
                    i(r, u, function (n) {
                        c.s.Wa(n, [t])
                    })
                }
            }

            function n(n) {
                return n.nodeType ? n : 0 < n.length ? n[0] : u
            }

            function h(i, u, e, h, l) {
                var l = l || {}, a = i && n(i), a = a && a.ownerDocument, v = l.templateEngine || t;
                c.Z.mb(e, v, a);
                e = v.renderTemplate(e, h, l, a);
                ("number" != typeof e.length || 0 < e.length && "number" != typeof e[0].nodeType) && o(Error("Template engine must return an array of DOM nodes"));
                a = f;
                switch (u) {
                    case"replaceChildren":
                        c.e.X(i, e);
                        a = r;
                        break;
                    case"replaceNode":
                        c.a.Na(i, e);
                        a = r;
                        break;
                    case"ignoreTargetNode":
                        break;
                    default:
                        o(Error("Unknown renderMode: " + u))
                }
                return a && (s(e, h), l.afterRender && l.afterRender(e, h.$data)), e
            }

            var t;
            c.ra = function (n) {
                n == e || n instanceof c.t || o(Error("templateEngine must inherit from ko.templateEngine"));
                t = n
            };
            c.qa = function (i, r, f, s, l) {
                if (f = f || {}, (f.templateEngine || t) == e && o(Error("Set a template engine before calling renderTemplate")), l = l || "replaceChildren", s) {
                    var a = n(s);
                    return c.h(function () {
                        var t = r && r instanceof c.z ? r : new c.z(c.a.d(r)), u = "function" == typeof i ? i(t.$data) : i, t = h(s, l, u, t, f);
                        "replaceNode" == l && (s = t, a = n(s))
                    }, u, {disposeWhen: function () {
                        return!a || !c.a.fa(a)
                    }, disposeWhenNodeIsRemoved: a && "replaceNode" == l ? a.parentNode : a})
                }
                return c.s.na(function (n) {
                    c.qa(i, r, f, n, "replaceNode")
                })
            };
            c.Fb = function (n, t, i, r, f) {
                function l(n, t) {
                    s(t, o);
                    i.afterRender && i.afterRender(t, n)
                }

                function a(t, r) {
                    var e = "function" == typeof n ? n(t) : n;
                    return o = f.createChildContext(c.a.d(t)), o.$index = r, h(u, "ignoreTargetNode", e, o, i)
                }

                var o;
                return c.h(function () {
                    var n = c.a.d(t) || [];
                    "undefined" == typeof n.length && (n = [n]);
                    n = c.a.aa(n, function (n) {
                        return i.includeDestroyed || n === e || n === u || !c.a.d(n._destroy)
                    });
                    c.a.Oa(r, n, a, i, l)
                }, u, {disposeWhenNodeIsRemoved: r})
            };
            c.c.template = {init: function (n, t) {
                var i = c.a.d(t());
                return"string" == typeof i || i.name || 1 != n.nodeType && 8 != n.nodeType || (i = 1 == n.nodeType ? n.childNodes : c.e.childNodes(n), i = c.a.Ab(i), new c.l.M(n).nodes(i)), {controlsDescendantBindings: r}
            }, update: function (n, t, i, f, e) {
                t = c.a.d(t());
                f = r;
                "string" == typeof t ? i = t : (i = t.name, "if"in t && (f = f && c.a.d(t["if"])), "ifnot"in t && (f = f && !c.a.d(t.ifnot)));
                var o = u;
                "object" == typeof t && "foreach"in t ? o = c.Fb(i || n, f && t.foreach || [], t, n, e) : f ? (e = "object" == typeof t && "data"in t ? e.createChildContext(c.a.d(t.data)) : e, o = c.qa(i || n, e, t, n)) : c.e.ha(n);
                e = o;
                (t = c.a.f.get(n, "__ko__templateSubscriptionDomDataKey__")) && "function" == typeof t.A && t.A();
                c.a.f.set(n, "__ko__templateSubscriptionDomDataKey__", e)
            }};
            c.g.D.template = function (n) {
                return n = c.g.W(n), 1 == n.length && n[0].unknown || c.g.wb(n, "name") ? u : "This template engine does not support anonymous templates nested within its templates"
            };
            c.e.C.template = r
        }();
        c.b("setTemplateEngine", c.ra);
        c.b("renderTemplate", c.qa), function () {
            c.a.O = function (n, t, i) {
                var r, l, a;
                if (i === e)return c.a.O(n, t, 1) || c.a.O(n, t, 10) || c.a.O(n, t, Number.MAX_VALUE);
                for (var n = n || [], t = t || [], o = n, h = t, f = [], r = 0; r <= h.length; r++)f[r] = [];
                for (r = 0, l = Math.min(o.length, i); r <= l; r++)f[0][r] = r;
                for (r = 1, l = Math.min(h.length, i); r <= l; r++)f[r][0] = r;
                for (var l = o.length, s, v = h.length, r = 1; r <= l; r++)for (s = Math.max(1, r - i), a = Math.min(v, r + i); s <= a; s++)f[s][r] = o[r - 1] === h[s - 1] ? f[s - 1][r - 1] : Math.min(f[s - 1][r] === e ? Number.MAX_VALUE : f[s - 1][r] + 1, f[s][r - 1] === e ? Number.MAX_VALUE : f[s][r - 1] + 1);
                if (i = n.length, o = t.length, h = [], r = f[o][i], r === e)f = u; else {
                    for (; 0 < i || 0 < o;)l = f[o][i], v = 0 < o ? f[o - 1][i] : r + 1, a = 0 < i ? f[o][i - 1] : r + 1, s = 0 < o && 0 < i ? f[o - 1][i - 1] : r + 1, (v === e || v < l - 1) && (v = r + 1), (a === e || a < l - 1) && (a = r + 1), s < l - 1 && (s = r + 1), v <= a && v < s ? (h.push({status: "added", value: t[o - 1]}), o--) : (a < v && a < s ? h.push({status: "deleted", value: n[i - 1]}) : (h.push({status: "retained", value: n[i - 1]}), o--), i--);
                    f = h.reverse()
                }
                return f
            }
        }();
        c.b("utils.compareArrays", c.a.O), function () {
            function n(n) {
                if (2 < n.length) {
                    for (var t = n[0], r = n[n.length - 1], i = [t]; t !== r;) {
                        if (t = t.nextSibling, !t)return;
                        i.push(t)
                    }
                    Array.prototype.splice.apply(n, [0, n.length].concat(i))
                }
            }

            function t(t, i, r, f, e) {
                var o = [], t = c.h(function () {
                    var t = i(r, e) || [];
                    0 < o.length && (n(o), c.a.Na(o, t), f && f(r, t));
                    o.splice(0, o.length);
                    c.a.N(o, t)
                }, u, {disposeWhenNodeIsRemoved: t, disposeWhen: function () {
                    return 0 == o.length || !c.a.fa(o[0])
                }});
                return{xb: o, h: t}
            }

            c.a.Oa = function (i, o, s, h, l) {
                for (var y, nt, o = o || [], h = h || {}, ut = c.a.f.get(i, "setDomNodeChildrenFromArrayMapping_lastMappingResult") === e, k = c.a.f.get(i, "setDomNodeChildrenFromArrayMapping_lastMappingResult") || [], p = c.a.T(k, function (n) {
                    return n.$a
                }), w = c.a.O(p, o), o = [], b = 0, v = [], d = 0, p = [], g = u, a = 0, ft = w.length; a < ft; a++)switch (w[a].status) {
                    case"retained":
                        y = k[b];
                        y.qb(d);
                        d = o.push(y);
                        0 < y.P.length && (g = y.P[y.P.length - 1]);
                        b++;
                        break;
                    case"deleted":
                        k[b].h.A();
                        n(k[b].P);
                        c.a.v(k[b].P, function (n) {
                            v.push({element: n, index: a, value: w[a].value});
                            g = n
                        });
                        b++;
                        break;
                    case"added":
                        for (var y = w[a].value, it = c.m(d), d = t(i, s, y, l, it), tt = d.xb, d = o.push({$a: w[a].value, P: tt, h: d.h, qb: it}), rt = 0, et = tt.length; rt < et; rt++)nt = tt[rt], p.push({element: nt, index: a, value: w[a].value}), g == u ? c.e.Ka(i, nt) : c.e.Fa(i, nt, g), g = nt;
                        l && l(y, tt, it)
                }
                if (c.a.v(v, function (n) {
                    c.F(n.element)
                }), s = f, !ut) {
                    if (h.afterAdd)for (a = 0; a < p.length; a++)h.afterAdd(p[a].element, p[a].index, p[a].value);
                    if (h.beforeRemove) {
                        for (a = 0; a < v.length; a++)h.beforeRemove(v[a].element, v[a].index, v[a].value);
                        s = r
                    }
                }
                if (!s && v.length)for (a = 0; a < v.length; a++)h = v[a].element, h.parentNode && h.parentNode.removeChild(h);
                c.a.f.set(i, "setDomNodeChildrenFromArrayMapping_lastMappingResult", o)
            }
        }();
        c.b("utils.setDomNodeChildrenFromArrayMapping", c.a.Oa);
        c.q = function () {
            this.allowTemplateRewriting = f
        };
        c.q.prototype = new c.t;
        c.q.prototype.renderTemplateSource = function (n) {
            var t = !(9 > c.a.ja) && n.nodes ? n.nodes() : u;
            return t ? c.a.L(t.cloneNode(r).childNodes) : (n = n.text(), c.a.pa(n))
        };
        c.q.K = new c.q;
        c.ra(c.q.K);
        c.b("nativeTemplateEngine", c.q), function () {
            c.ma = function () {
                var n = this.vb = function () {
                    if ("undefined" == typeof jQuery || !jQuery.tmpl)return 0;
                    try {
                        if (0 <= jQuery.tmpl.tag.tmpl.open.toString().indexOf("__"))return 2
                    } catch (n) {
                    }
                    return 1
                }();
                this.renderTemplateSource = function (i, r, f) {
                    f = f || {};
                    2 > n && o(Error("Your version of jQuery.tmpl is too old. Please upgrade to jQuery.tmpl 1.0.0pre or later."));
                    var e = i.data("precompiled");
                    return e || (e = i.text() || "", e = jQuery.template(u, "{{ko_with $item.koBindingContext}}" + e + "{{/ko_with}}"), i.data("precompiled", e)), i = [r.$data], r = jQuery.extend({koBindingContext: r}, f.templateOptions), r = jQuery.tmpl(e, i, r), r.appendTo(t.createElement("div")), jQuery.fragments = {}, r
                };
                this.createJavaScriptEvaluatorBlock = function (n) {
                    return"{{ko_code ((function() { return " + n + " })()) }}"
                };
                this.addTemplate = function (n, i) {
                    t.write("<script type='text/html' id='" + n + "'>" + i + "<\/script>")
                };
                0 < n && (jQuery.tmpl.tag.ko_code = {open: "__.push($1 || '');"}, jQuery.tmpl.tag.ko_with = {open: "with($1) {", close: "} "})
            };
            c.ma.prototype = new c.t;
            var n = new c.ma;
            0 < n.vb && c.ra(n);
            c.b("jqueryTmplTemplateEngine", c.ma)
        }()
    }

    var e = void 0, r = !0, u = null, f = !1;
    "function" == typeof require && "object" == typeof exports && "object" == typeof module ? h(module.exports || exports) : "function" == typeof define && define.amd ? define(["exports"], h) : h(n.ko = {});
    r
})(window, document, navigator);
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.viewPart.GiftListInsertSkuV2.js
 */
Array.prototype.add = function (n) {
    this.unshift(n);
    $.unique(this)
};
selectedToInsert = new Array(0);
Config = {UrlNewList: "/no-cache/giftlistv2/skutonewlist", UrlExistingList: "/no-cache/giftlistv2/skutolist", GetUrlContent: function (n) {
    return $("#hdn_" + n).text()
}, Origin: function () {
    return $("#giftlistproduct").length > 0 ? "g" : selectedToInsert.length > 0 ? "s" : $("#giftlistproduct").length > 0 ? "giftlist" : void 0
}, OriginId: function () {
}};
$(document).ready(function () {
    BindSkuDataListener()
});
$(document).ajaxStop(function () {
    CheckThickBox();
    BindEvents();
    IsAuthenticated();
    var n = 0;
    $(selectedToInsert).each(function (t) {
        n += parseInt(selectedToInsert[t].split("-")[1])
    });
    updateInsertSkuSelectionCount("+", n)
})