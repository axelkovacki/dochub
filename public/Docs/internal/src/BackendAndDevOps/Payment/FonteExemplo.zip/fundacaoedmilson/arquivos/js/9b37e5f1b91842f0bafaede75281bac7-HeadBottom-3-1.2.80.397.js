/*! VTEX Commerce Suite Generated */
/*! 
 * inlinescript
 */
function bindMultipleSearchNavigatorCheckBoxes() {
    $(".multi-search-checkbox").click(function () {
        onSearchNavigatorCheckBoxClick(this)
    })
}
function bindAdvancedSearchBoxes() {
    $(".advanced-search-box").blur(function () {
        onAdvancedSearchBoxBlur(this)
    })
}
function cleanAdvancedSearchBoxes() {
    $(".advanced-search-box").each(function () {
        this.value = ""
    })
}
function bindSearchNavigatorButtons() {
    $("a.search-filter-button").click(function () {
        onSearchNavigatorButtonClick(this)
    })
}
function onSearchNavigatorCheckBoxClick(n) {
    var t = $(n).attr("rel");
    n.checked ? searchFiltersToAdd.add(t) : searchFiltersToAdd.remove(t)
}
function removeFTextFilter(n, t) {
    for (var r = !1, i = 0; i < n.length && !r;)n[i].split("&")[1] == t.split("&")[1] && (n.splice(i, 1), r = !0), i++
}
function onAdvancedSearchBoxBlur(n) {
    var r = $(n).attr("rel"), u = jQuery.trim($(n).val()), f, t;
    if (removeFTextFilter(searchFiltersToAdd, r), u != "")for (f = r.replace("##value##", u), t = f.split("&"), i = t.length - 1; i >= 0; --i)$.inArray(t[i], searchFiltersToAdd) == -1 && searchFiltersToAdd.add(t[i])
}
function foundOtherAdvancedSearchField(n) {
    for (var t = !1, i = 0; !t && i < n.length;)t = n[i].indexOf("specificationIndexed_") != -1, i++;
    return t
}
function removeQueryToFiltersToAdd(n) {
    var r = n.split("?"), t;
    if (r.length > 1) {
        for (t = r[1].split("&"), i = t.length - 1; i >= 0; --i)t[i].indexOf("map=") != -1 && t[i].length > 0 && (t[i].indexOf("specificationIndexed_", 0) == -1 || !foundOtherAdvancedSearchField(searchFiltersToAdd)) && searchFiltersToAdd.add(unescape(t[i]));
        return r[0] + "?"
    }
    return r[0].replace("&", "?")
}
function onSearchNavigatorButtonClick(n) {
    var t = removeQueryToFiltersToAdd(partialSearchUrl), u = !1;
    $.inArray("Mode=M", searchFiltersToAdd) == -1 && n.search.indexOf("Mode=M") == -1 ? $(n).hasClass("bt-refinar") && (searchFiltersToAdd.add("Mode=M"), u = !0) : u = !0;
    var r = "", f = "/busca/";
    for (i = 0; i < searchFiltersToAdd.length; i++)r += "&" + searchFiltersToAdd[i], searchFiltersToAdd[i].indexOf("fq=specificationFilter_") == 0 && $("input[rel='" + searchFiltersToAdd[i] + "']").attr("checked", !1);
    r.length > 0 && (r = r.substring(1), t += r, f += "?" + r);
    t.length > 0 && t[0] == "?" && (t = t.substring(1));
    currentPathAndQuery = "";
    n.pathname.length > 0 && (currentPathAndQuery = (n.pathname.indexOf("/") == 0 ? n.pathname : "/" + n.pathname) + n.search);
    u ? $.ajax({url: "/doresolvecriteriatofriendlyurl/", dataType: "text", type: "POST", data: {currentPathAndQuery: currentPathAndQuery, newPathAndQuery: f}, success: function (n) {
        n != null && (document.location.href = "/" + n)
    }}) : document.location.href = t
}
function goToTopPage() {
    $("html, body").animate({scrollTop: 0}, "slow")
}
function enableFullTextSearchBox(n, t, i, r, u, f) {
    $("#" + n).val() == "" && $("#" + n).val(f);
    $("#" + n).focus(function () {
        $(this).filter(function () {
            return $(this).val() == "" || $(this).val() == f
        }).val("")
    });
    $("#" + n).blur(function () {
        $(this).filter(function () {
            return $(this).val() === ""
        }).val(f)
    });
    $("#" + t).change(function () {
        var n = $("#" + i);
        $(n).val("");
        $(this).val() === currentDept ? $(n).removeAttr("disabled") : $(n).attr("disabled", "disabled")
    });
    $("#" + n).keypress(function (r) {
        return r.which === 13 ? (doSearch(n, t, i, u, f), !1) : !0
    });
    $("#" + r).click(function () {
        doSearch(n, t, i, u, f)
    })
}
function containsIllegalPathCharacter(n) {
    var t = new RegExp("['\"%#&*+|<>?/\\-.]", "gi");
    return t.exec(n) != null
}
function removeChars(n) {
    var t = n.replace(",", ""), r, u, i;
    for (t = t.replace('"', "+"), r = "'!@#$%&+,*()-?:;={}][/¨ÄÅÁÂÀÃäáâàãÉÊËÈéêëèÍÎÏÌíîïìÖÓÔÒÕöóôòõÜÚÛüúûùÇç /", u = "-----------------------AAAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUuuuuCc--", i = 0; i < r.length; i++)t = t.replace(r[i], u[i]);
    return t
}
function doSearch(n, t, i, r, u) {
    var f = jQuery.trim($("#" + n).val()), b = $("#" + t).val(), c = $("#" + i).val(), a = $("#" + t)[0], s = a.selectedIndex != 0 ? a[a.selectedIndex].innerHTML.toLowerCase() : "", v, e, o, l, y, p, h, w;
    if (s = removeChars(s), f != "" && f != u) {
        if (v = new RegExp("['\"%#&*+|<>?/\\-]", "g"), f = f.replace(v, " ").trim(), containsIllegalPathCharacter(f) || f.toLowerCase() === "admin" || f.toLowerCase() === "webservice" || f.toLowerCase() === "admin/a")r = r.replace("SEARCHTERM", "busca"), e = r.indexOf("?") < 0 ? "?" : "&", r += c !== "" ? e + "fq=specificationIndexed_" + c + ":" + encodeURIComponent(f) : e + "ft=" + encodeURIComponent(f), e = r.indexOf("?") < 0 ? "?" : "&", s !== "" && (r += e + "fq=C:" + b + "/"); else {
            while (r.indexOf("SEARCHTERM") > 0)r = r.replace("SEARCHTERM", encodeURIComponent(f));
            e = r.indexOf("?") < 0 ? "?" : "&";
            c !== "" && (r += e + "map=specificationIndexed_" + c);
            e = r.indexOf("?") < 0 ? "?" : "&";
            s !== "" && (r = "/" + s + r)
        }
        if (jQuery.trim(f) !== "")if (suggestionsStack === "" || suggestionsStack === null)document.location.href = r; else if (o = suggestionsStack.split("£"), o.length > 1) {
            for (y = o.length - 1, p = !1, h = o.length - 1; h >= 1; --h)if (l = o[h].split("¢"), w = l[0].replace(v, " ").trim(), jQuery.trim(f) == jQuery.trim(w)) {
                y = h;
                p = !0;
                break
            }
            p ? (l = o[y].split("¢"), document.location.href = l[1]) : document.location.href = r
        }
    }
}
var defaultUtmFromFolder = "", ___scriptPath, ___scriptPathTransac, searchFiltersToAdd, partialSearchUrl, currentDept, suggestionsStack;
/*! 
 * inlinescript
 */
vtxctx = {searchTerm: "giftlist", isOrder: "0", isCheck: "0", isCart: "0", actionType: "", actionValue: "", login: "", url: "doe.fundacaoedmilson.org.br", transurl: "doe.fundacaoedmilson.org.br"};
/*! 
 * inlinescript
 */
___scriptPath = "";
/*! 
 * inlinescript
 */
___scriptPathTransac = "";
/*! 
 * inlinescript
 */
var jscheckoutUrl = "https://doe.fundacaoedmilson.org.br/checkout/#/cart", jscheckoutAddUrl = "https://doe.fundacaoedmilson.org.br/checkout/cart/add", jscheckoutGiftListId = "", jsnomeSite = "fundacaoedmilson", jsnomeLoja = "fundacaoedmilson", jssalesChannel = "1", defaultStoreCurrency = "R$", localeInfo = {CountryCode: "BRA", CultureCode: "pt-BR", CurrencyLocale: {RegionDisplayName: "Brazil", RegionName: "BR", RegionNativeName: "Brasil", TwoLetterIsoRegionName: "BR", CurrencyEnglishName: "Real", CurrencyNativeName: "Real", CurrencySymbol: "R$", ISOCurrencySymbol: "BRL", Locale: 1046, Format: {CurrencyDecimalDigits: 2, CurrencyDecimalSeparator: ",", CurrencyGroupSeparator: ".", CurrencyGroupSize: 3, StartsWithCurrencySymbol: !0}, FlagUrl: "https://www.geonames.org/flags/x/br.gif"}};
/*! 
 * inlinescript
 */
(function () {
    var n, t;
    try {
        n = document.createElement("script");
        n.type = "text/javascript";
        n.async = !0;
        n.src = "//dmx56ht1p4edz.cloudfront.net/rc.js?an=fundacaoedmilson";
        n.target = "_blank";
        t = document.getElementsByTagName("script")[0];
        t.parentNode.insertBefore(n, t)
    } catch (i) {
    }
})();
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/jquery.ui.core.js
 */
/*!
 * jQuery UI 1.8
 *
 * Copyright (c) 2010 AUTHORS.txt (https://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * https://docs.jquery.com/UI
 */
jQuery.ui || function (n) {
    n.ui = {version: "1.8", plugin: {add: function (t, i, r) {
        var f = n.ui[t].prototype;
        for (var u in r)f.plugins[u] = f.plugins[u] || [], f.plugins[u].push([i, r[u]])
    }, call: function (n, t, i) {
        var u = n.plugins[t], r;
        if (u && n.element[0].parentNode)for (r = 0; r < u.length; r++)n.options[u[r][0]] && u[r][1].apply(n.element, i)
    }}, contains: function (n, t) {
        return document.compareDocumentPosition ? n.compareDocumentPosition(t) & 16 : n !== t && n.contains(t)
    }, hasScroll: function (t, i) {
        if (n(t).css("overflow") == "hidden")return!1;
        var r = i && i == "left" ? "scrollLeft" : "scrollTop", u = !1;
        return t[r] > 0 ? !0 : (t[r] = 1, u = t[r] > 0, t[r] = 0, u)
    }, isOverAxis: function (n, t, i) {
        return n > t && n < t + i
    }, isOver: function (t, i, r, u, f, e) {
        return n.ui.isOverAxis(t, r, f) && n.ui.isOverAxis(i, u, e)
    }, keyCode: {BACKSPACE: 8, CAPS_LOCK: 20, COMMA: 188, CONTROL: 17, DELETE: 46, DOWN: 40, END: 35, ENTER: 13, ESCAPE: 27, HOME: 36, INSERT: 45, LEFT: 37, NUMPAD_ADD: 107, NUMPAD_DECIMAL: 110, NUMPAD_DIVIDE: 111, NUMPAD_ENTER: 108, NUMPAD_MULTIPLY: 106, NUMPAD_SUBTRACT: 109, PAGE_DOWN: 34, PAGE_UP: 33, PERIOD: 190, RIGHT: 39, SHIFT: 16, SPACE: 32, TAB: 9, UP: 38}};
    n.fn.extend({_focus: n.fn.focus, focus: function (t, i) {
        return typeof t == "number" ? this.each(function () {
            var r = this;
            setTimeout(function () {
                n(r).focus();
                i && i.call(r)
            }, t)
        }) : this._focus.apply(this, arguments)
    }, enableSelection: function () {
        return this.attr("unselectable", "off").css("MozUserSelect", "").unbind("selectstart.ui")
    }, disableSelection: function () {
        return this.attr("unselectable", "on").css("MozUserSelect", "none").bind("selectstart.ui", function () {
            return!1
        })
    }, scrollParent: function () {
        var t;
        return t = n.browser.msie && /(static|relative)/.test(this.css("position")) || /absolute/.test(this.css("position")) ? this.parents().filter(function () {
            return/(relative|absolute|fixed)/.test(n.curCSS(this, "position", 1)) && /(auto|scroll)/.test(n.curCSS(this, "overflow", 1) + n.curCSS(this, "overflow-y", 1) + n.curCSS(this, "overflow-x", 1))
        }).eq(0) : this.parents().filter(function () {
            return/(auto|scroll)/.test(n.curCSS(this, "overflow", 1) + n.curCSS(this, "overflow-y", 1) + n.curCSS(this, "overflow-x", 1))
        }).eq(0), /fixed/.test(this.css("position")) || !t.length ? n(document) : t
    }, zIndex: function (t) {
        if (t !== undefined)return this.css("zIndex", t);
        if (this.length)for (var i = n(this[0]), r, u; i.length && i[0] !== document;) {
            if (r = i.css("position"), (r == "absolute" || r == "relative" || r == "fixed") && (u = parseInt(i.css("zIndex")), !isNaN(u) && u != 0))return u;
            i = i.parent()
        }
        return 0
    }});
    n.extend(n.expr[":"], {data: function (t, i, r) {
        return!!n.data(t, r[3])
    }, focusable: function (t) {
        var i = t.nodeName.toLowerCase(), r = n.attr(t, "tabindex");
        return(/input|select|textarea|button|object/.test(i) ? !t.disabled : "a" == i || "area" == i ? t.href || !isNaN(r) : !isNaN(r)) && !n(t)["area" == i ? "parents" : "closest"](":hidden").length
    }, tabbable: function (t) {
        var i = n.attr(t, "tabindex");
        return(isNaN(i) || i >= 0) && n(t).is(":focusable")
    }})
}(jQuery);
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/autocomplete/jquery.ui.widget.js
 */
/*!
 * jQuery UI Widget 1.8
 *
 * Copyright (c) 2010 AUTHORS.txt (https://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * https://docs.jquery.com/UI/Widget
 */
(function (n) {
    var t = n.fn.remove;
    n.fn.remove = function (i, r) {
        return this.each(function () {
            return r || (!i || n.filter(i, [this]).length) && n("*", this).add(this).each(function () {
                n(this).triggerHandler("remove")
            }), t.call(n(this), i, r)
        })
    };
    n.widget = function (t, i, r) {
        var u = t.split(".")[0], e, f;
        t = t.split(".")[1];
        e = u + "-" + t;
        r || (r = i, i = n.Widget);
        n.expr[":"][e] = function (i) {
            return!!n.data(i, t)
        };
        n[u] = n[u] || {};
        n[u][t] = function (n, t) {
            arguments.length && this._createWidget(n, t)
        };
        f = new i;
        f.options = n.extend({}, f.options);
        n[u][t].prototype = n.extend(!0, f, {namespace: u, widgetName: t, widgetEventPrefix: n[u][t].prototype.widgetEventPrefix || t, widgetBaseClass: e}, r);
        n.widget.bridge(t, n[u][t])
    };
    n.widget.bridge = function (t, i) {
        n.fn[t] = function (r) {
            var u = typeof r == "string", f = Array.prototype.slice.call(arguments, 1), e = this;
            return(r = !u && f.length ? n.extend.apply(null, [!0, r].concat(f)) : r, u && r.substring(0, 1) === "_") ? e : (u ? this.each(function () {
                var i = n.data(this, t), u = i && n.isFunction(i[r]) ? i[r].apply(i, f) : i;
                if (u !== i && u !== undefined)return e = u, !1
            }) : this.each(function () {
                var u = n.data(this, t);
                u ? (r && u.option(r), u._init()) : n.data(this, t, new i(r, this))
            }), e)
        }
    };
    n.Widget = function (n, t) {
        arguments.length && this._createWidget(n, t)
    };
    n.Widget.prototype = {widgetName: "widget", widgetEventPrefix: "", options: {disabled: !1}, _createWidget: function (t, i) {
        this.element = n(i).data(this.widgetName, this);
        this.options = n.extend(!0, {}, this.options, n.metadata && n.metadata.get(i)[this.widgetName], t);
        var r = this;
        this.element.bind("remove." + this.widgetName, function () {
            r.destroy()
        });
        this._create();
        this._init()
    }, _create: function () {
    }, _init: function () {
    }, destroy: function () {
        this.element.unbind("." + this.widgetName).removeData(this.widgetName);
        this.widget().unbind("." + this.widgetName).removeAttr("aria-disabled").removeClass(this.widgetBaseClass + "-disabled " + this.namespace + "-state-disabled")
    }, widget: function () {
        return this.element
    }, option: function (t, i) {
        var r = t, u = this;
        if (arguments.length === 0)return n.extend({}, u.options);
        if (typeof t == "string") {
            if (i === undefined)return this.options[t];
            r = {};
            r[t] = i
        }
        return n.each(r, function (n, t) {
            u._setOption(n, t)
        }), u
    }, _setOption: function (n, t) {
        return this.options[n] = t, n === "disabled" && this.widget()[t ? "addClass" : "removeClass"](this.widgetBaseClass + "-disabled " + this.namespace + "-state-disabled").attr("aria-disabled", t), this
    }, enable: function () {
        return this._setOption("disabled", !1)
    }, disable: function () {
        return this._setOption("disabled", !0)
    }, _trigger: function (t, i, r) {
        var e = this.options[t], u, f;
        if (i = n.Event(i), i.type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), r = r || {}, i.originalEvent)for (u = n.event.props.length; u;)f = n.event.props[--u], i[f] = i.originalEvent[f];
        return this.element.trigger(i, r), !(n.isFunction(e) && e.call(this.element[0], i, r) === !1 || i.isDefaultPrevented())
    }}
})(jQuery);
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/autocomplete/jquery.ui.position.js
 */
(function (n) {
    n.ui = n.ui || {};
    var r = /left|center|right/, t = "center", u = /top|center|bottom/, i = "center", f = n.fn.position, e = n.fn.offset;
    n.fn.position = function (e) {
        if (!e || !e.of)return f.apply(this, arguments);
        e = n.extend({}, e);
        var h = n(e.of), a = (e.collision || "flip").split(" "), s = e.offset ? e.offset.split(" ") : [0, 0], c, l, o;
        return e.of.nodeType === 9 ? (c = h.width(), l = h.height(), o = {top: 0, left: 0}) : e.of.scrollTo && e.of.document ? (c = h.width(), l = h.height(), o = {top: h.scrollTop(), left: h.scrollLeft()}) : e.of.preventDefault ? (e.at = "left top", c = l = 0, o = {top: e.of.pageY, left: e.of.pageX}) : (c = h.outerWidth(), l = h.outerHeight(), o = h.offset()), n.each(["my", "at"], function () {
            var n = (e[this] || "").split(" ");
            n.length === 1 && (n = r.test(n[0]) ? n.concat([i]) : u.test(n[0]) ? [t].concat(n) : [t, i]);
            n[0] = r.test(n[0]) ? n[0] : t;
            n[1] = u.test(n[1]) ? n[1] : i;
            e[this] = n
        }), a.length === 1 && (a[1] = a[0]), s[0] = parseInt(s[0], 10) || 0, s.length === 1 && (s[1] = s[0]), s[1] = parseInt(s[1], 10) || 0, e.at[0] === "right" ? o.left += c : e.at[0] === t && (o.left += c / 2), e.at[1] === "bottom" ? o.top += l : e.at[1] === i && (o.top += l / 2), o.left += s[0], o.top += s[1], this.each(function () {
            var u = n(this), f = u.outerWidth(), h = u.outerHeight(), r = n.extend({}, o);
            e.my[0] === "right" ? r.left -= f : e.my[0] === t && (r.left -= f / 2);
            e.my[1] === "bottom" ? r.top -= h : e.my[1] === i && (r.top -= h / 2);
            n.each(["left", "top"], function (t, i) {
                n.ui.position[a[t]] && n.ui.position[a[t]][i](r, {targetWidth: c, targetHeight: l, elemWidth: f, elemHeight: h, offset: s, my: e.my, at: e.at})
            });
            n.fn.bgiframe && u.bgiframe();
            u.offset(n.extend(r, {using: e.using}))
        })
    };
    n.ui.position = {fit: {left: function (t, i) {
        var r = n(window), u = t.left + i.elemWidth - r.width() - r.scrollLeft();
        t.left = u > 0 ? t.left - u : Math.max(0, t.left)
    }, top: function (t, i) {
        var r = n(window), u = t.top + i.elemHeight - r.height() - r.scrollTop();
        t.top = u > 0 ? t.top - u : Math.max(0, t.top)
    }}, flip: {left: function (t, i) {
        if (i.at[0] !== "center") {
            var r = n(window), e = t.left + i.elemWidth - r.width() - r.scrollLeft(), u = i.my[0] === "left" ? -i.elemWidth : i.my[0] === "right" ? i.elemWidth : 0, f = -2 * i.offset[0];
            t.left += t.left < 0 ? u + i.targetWidth + f : e > 0 ? u - i.targetWidth + f : 0
        }
    }, top: function (t, i) {
        if (i.at[1] !== "center") {
            var r = n(window), e = t.top + i.elemHeight - r.height() - r.scrollTop(), u = i.my[1] === "top" ? -i.elemHeight : i.my[1] === "bottom" ? i.elemHeight : 0, o = i.at[1] === "top" ? i.targetHeight : -i.targetHeight, f = -2 * i.offset[1];
            t.top += t.top < 0 ? u + i.targetHeight + f : e > 0 ? u + o + f : 0
        }
    }}};
    n.offset.setOffset || (n.offset.setOffset = function (t, i) {
        /static/.test(n.curCSS(t, "position")) && (t.style.position = "relative");
        var r = n(t), u = r.offset(), e = parseInt(n.curCSS(t, "top", !0), 10) || 0, o = parseInt(n.curCSS(t, "left", !0), 10) || 0, f = {top: i.top - u.top + e, left: i.left - u.left + o};
        "using"in i ? i.using.call(t, f) : r.css(f)
    }, n.fn.offset = function (t) {
        var i = this[0];
        return!i || !i.ownerDocument ? null : t ? this.each(function () {
            n.offset.setOffset(this, t)
        }) : e.call(this)
    })
})(jQuery);
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/autocomplete/jquery.ui.autocomplete.js
 */
(function (n) {
    n.widget("ui.autocomplete", {options: {minLength: 1, delay: 300}, _create: function () {
        var t = this, i = this.element[0].ownerDocument;
        this.element.addClass("ui-autocomplete-input").attr("autocomplete", "off").attr({role: "textbox", "aria-autocomplete": "list", "aria-haspopup": "true"}).bind("keydown.autocomplete", function (i) {
            var r = n.ui.keyCode;
            switch (i.keyCode) {
                case r.PAGE_UP:
                    t._move("previousPage", i);
                    break;
                case r.PAGE_DOWN:
                    t._move("nextPage", i);
                    break;
                case r.UP:
                    t._move("previous", i);
                    i.preventDefault();
                    break;
                case r.DOWN:
                    t._move("next", i);
                    i.preventDefault();
                    break;
                case r.ENTER:
                    t.menu.active && i.preventDefault();
                case r.TAB:
                    if (!t.menu.active)return;
                    t.menu.select();
                    break;
                case r.ESCAPE:
                    t.element.val(t.term);
                    t.close(i);
                    break;
                case r.SHIFT:
                case r.CONTROL:
                case 18:
                    break;
                default:
                    clearTimeout(t.searching);
                    t.searching = setTimeout(function () {
                        t.search(null, i)
                    }, t.options.delay)
            }
        }).bind("focus.autocomplete", function () {
            t.previous = t.element.val()
        }).bind("blur.autocomplete", function (n) {
            clearTimeout(t.searching);
            t.closing = setTimeout(function () {
                t.close(n)
            }, 150)
        });
        this._initSource();
        this.response = function () {
            return t._response.apply(t, arguments)
        };
        this.menu = n("<ul><\/ul>").addClass("ui-autocomplete").appendTo("body", i).menu({focus: function (n, i) {
            var r = i.item.data("item.autocomplete");
            !1 !== t._trigger("focus", null, {item: r}) && t.element.val(r.value)
        }, selected: function (n, r) {
            var u = r.item.data("item.autocomplete");
            !1 !== t._trigger("select", n, {item: u}) && t.element.val(u.value);
            t.close(n);
            t.previous = t.element.val();
            t.element[0] !== i.activeElement && t.element.focus()
        }, blur: function () {
            t.menu.element.is(":visible") && t.element.val(t.term)
        }}).zIndex(this.element.zIndex() + 10).css({top: 0, left: 0}).hide().data("menu");
        n.fn.bgiframe && this.menu.element.bgiframe()
    }, destroy: function () {
        this.element.removeClass("ui-autocomplete-input ui-widget ui-widget-content").removeAttr("autocomplete").removeAttr("role").removeAttr("aria-autocomplete").removeAttr("aria-haspopup");
        this.menu.element.remove();
        n.Widget.prototype.destroy.call(this)
    }, _setOption: function (t) {
        n.Widget.prototype._setOption.apply(this, arguments);
        t === "source" && this._initSource()
    }, _initSource: function () {
        var t, i;
        n.isArray(this.options.source) ? (t = this.options.source, this.source = function (i, r) {
            var u = new RegExp(n.ui.autocomplete.escapeRegex(i.term), "i");
            r(n.grep(t, function (n) {
                return u.test(n.label || n.value || n)
            }))
        }) : typeof this.options.source == "string" ? (i = this.options.source, this.source = function (t, r) {
            n.getJSON(i, t, r)
        }) : this.source = this.options.source
    }, search: function (n, t) {
        return(n = n != null ? n : this.element.val(), n.length < this.options.minLength) ? this.close(t) : (clearTimeout(this.closing), this._trigger("search") === !1) ? void 0 : this._search(n)
    }, _search: function (n) {
        this.term = this.element.addClass("ui-autocomplete-loading").val();
        this.source({term: n}, this.response)
    }, _response: function (n) {
        n.length ? (n = this._normalize(n), this._suggest(n), this._trigger("open")) : this.close();
        this.element.removeClass("ui-autocomplete-loading")
    }, close: function (n) {
        clearTimeout(this.closing);
        this.menu.element.is(":visible") && (this._trigger("close", n), this.menu.element.hide(), this.menu.deactivate());
        this.previous !== this.element.val() && this._trigger("change", n)
    }, _normalize: function (t) {
        return t.length && t[0].label && t[0].value ? t : n.map(t, function (t) {
            return typeof t == "string" ? {label: t, value: t} : n.extend({label: t.label || t.value, value: t.value || t.label}, t)
        })
    }, _suggest: function (n) {
        var t = this.menu.element.empty().zIndex(this.element.zIndex() + 10), i, r;
        this._renderMenu(t, n);
        this.menu.deactivate();
        this.menu.refresh();
        this.menu.element.show().position({my: "left top", at: "left bottom", of: this.element, collision: "none"});
        i = t.width("").width();
        r = this.element.width();
        t.width(Math.max(i, r))
    }, _renderMenu: function (t, i) {
        var r = this;
        n.each(i, function (n, i) {
            r._renderItem(t, i)
        })
    }, _renderItem: function (t, i) {
        return n("<li><\/li>").data("item.autocomplete", i).append("<a>" + i.label + "<\/a>").appendTo(t)
    }, _move: function (n, t) {
        if (!this.menu.element.is(":visible")) {
            this.search(null, t);
            return
        }
        if (this.menu.first() && /^previous/.test(n) || this.menu.last() && /^next/.test(n)) {
            this.element.val(this.term);
            this.menu.deactivate();
            return
        }
        this.menu[n]()
    }, widget: function () {
        return this.menu.element
    }});
    n.extend(n.ui.autocomplete, {escapeRegex: function (n) {
        return n.replace(/([\^\$\(\)\[\]\{\}\*\.\+\?\|\\])/gi, "\\$1")
    }})
})(jQuery), function (n) {
    n.widget("ui.menu", {_create: function () {
        var n = this;
        this.element.addClass("ui-menu ui-widget ui-widget-content ui-corner-all").attr({role: "listbox", "aria-activedescendant": "ui-active-menuitem"}).click(function (t) {
            t.preventDefault();
            n.select()
        });
        this.refresh()
    }, refresh: function () {
        var t = this, i = this.element.children("li:not(.ui-menu-item):has(a)").addClass("ui-menu-item").attr("role", "menuitem");
        i.children("a").addClass("ui-corner-all").attr("tabindex", -1).mouseenter(function () {
            t.activate(n(this).parent())
        }).mouseleave(function () {
            t.deactivate()
        })
    }, activate: function (n) {
        if (this.deactivate(), this.hasScroll()) {
            var t = n.offset().top - this.element.offset().top, i = this.element.attr("scrollTop"), r = this.element.height();
            t < 0 ? this.element.attr("scrollTop", i + t) : t > r && this.element.attr("scrollTop", i + t - r + n.height())
        }
        this.active = n.eq(0).children("a").addClass("ui-state-hover").attr("id", "ui-active-menuitem").end();
        this._trigger("focus", null, {item: n})
    }, deactivate: function () {
        this.active && (this.active.children("a").removeClass("ui-state-hover").removeAttr("id"), this._trigger("blur"), this.active = null)
    }, next: function () {
        this.move("next", "li:first")
    }, previous: function () {
        this.move("prev", "li:last")
    }, first: function () {
        return this.active && !this.active.prev().length
    }, last: function () {
        return this.active && !this.active.next().length
    }, move: function (n, t) {
        if (!this.active) {
            this.activate(this.element.children(t));
            return
        }
        var i = this.active[n]();
        i.length ? this.activate(i) : this.activate(this.element.children(t))
    }, nextPage: function () {
        if (this.hasScroll()) {
            if (!this.active || this.last()) {
                this.activate(this.element.children(":first"));
                return
            }
            var i = this.active.offset().top, r = this.element.height(), t = this.element.children("li").filter(function () {
                var t = n(this).offset().top - i - r + n(this).height();
                return t < 10 && t > -10
            });
            t.length || (t = this.element.children(":last"));
            this.activate(t)
        } else this.activate(this.element.children(!this.active || this.last() ? ":first" : ":last"))
    }, previousPage: function () {
        if (this.hasScroll()) {
            if (!this.active || this.first()) {
                this.activate(this.element.children(":last"));
                return
            }
            var t = this.active.offset().top, i = this.element.height();
            result = this.element.children("li").filter(function () {
                var r = n(this).offset().top - t + i - n(this).height();
                return r < 10 && r > -10
            });
            result.length || (result = this.element.children(":first"));
            this.activate(result)
        } else this.activate(this.element.children(!this.active || this.first() ? ":last" : ":first"))
    }, hasScroll: function () {
        return this.element.height() < this.element.attr("scrollHeight")
    }, select: function () {
        this._trigger("selected", null, {item: this.active})
    }})
}(jQuery);
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.commerce.search.js
 */
searchFiltersToAdd = new Array(0);
partialSearchUrl = "/busca/?";
$(document).ready(function () {
    bindMultipleSearchNavigatorCheckBoxes();
    bindAdvancedSearchBoxes();
    cleanAdvancedSearchBoxes();
    bindSearchNavigatorButtons()
});
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.viewPart.fullTextSearchBox.js
 */
String.prototype.trim || (String.prototype.trim = function () {
    return this.replace(/^\s+|\s+$/g, "")
});
currentDept = "0";
suggestionsStack = "";
$(document).ready(function () {
    var n = function (n) {
        document.location.href = n
    }, t = function (n) {
        return{label: (n.thumb != "" ? n.thumb + " " : "") + n.name, value: n.name, href: n.href, criteria: n.criteria}
    }, i = function (n, i) {
        $.ajax({url: "/buscaautocomplete/", dataType: "json", data: {maxRows: 12, productNameContains: n.term, suggestionsStack: suggestionsStack}, success: function (n) {
            n && i($.map(n.itemsReturned, t))
        }})
    };
    $.fn.autocomplete && $(".fulltext-search-box").autocomplete({source: i, minLength: 3, delay: 500, select: function (t, i) {
        n(i.item.href)
    }, open: function () {
        $(this).removeClass("ui-corner-all").addClass("ui-corner-top")
    }, close: function () {
        $(this).removeClass("ui-corner-top").addClass("ui-corner-all")
    }, focus: function (n, t) {
        suggestionsStack = t.item.criteria
    }})
})