/*! VTEX Commerce Suite Generated */
/*! 
 * inlinescript
 */
var defaultUtmFromFolder = "", ___scriptPath, ___scriptPathTransac, vtexTagManagerHelper;
/*! 
 * inlinescript
 */
vtxctx = {searchTerm: "politica-privacidade", isOrder: "0", isCheck: "0", isCart: "0", actionType: "", actionValue: "", login: "", url: "doe.fundacaoedmilson.org.br", transurl: "doe.fundacaoedmilson.org.br"};
/*! 
 * inlinescript
 */
___scriptPath = "";
/*! 
 * inlinescript
 */
___scriptPathTransac = "";
/*! 
 * inlinescript
 */
var jscheckoutUrl = "https://doe.fundacaoedmilson.org.br/checkout/#/cart", jscheckoutAddUrl = "https://doe.fundacaoedmilson.org.br/checkout/cart/add", jscheckoutGiftListId = "", jsnomeSite = "fundacaoedmilson", jsnomeLoja = "fundacaoedmilson", jssalesChannel = "1", defaultStoreCurrency = "R$", localeInfo = {CountryCode: "BRA", CultureCode: "pt-BR", CurrencyLocale: {RegionDisplayName: "Brazil", RegionName: "BR", RegionNativeName: "Brasil", TwoLetterIsoRegionName: "BR", CurrencyEnglishName: "Real", CurrencyNativeName: "Real", CurrencySymbol: "R$", ISOCurrencySymbol: "BRL", Locale: 1046, Format: {CurrencyDecimalDigits: 2, CurrencyDecimalSeparator: ",", CurrencyGroupSeparator: ".", CurrencyGroupSize: 3, StartsWithCurrencySymbol: !0}, FlagUrl: "https://www.geonames.org/flags/x/br.gif"}};
/*! 
 * inlinescript
 */
(function () {
    var n, t;
    try {
        n = document.createElement("script");
        n.type = "text/javascript";
        n.async = !0;
        n.src = "//dmx56ht1p4edz.cloudfront.net/rc.js?an=fundacaoedmilson";
        n.target = "_blank";
        t = document.getElementsByTagName("script")[0];
        t.parentNode.insertBefore(n, t)
    } catch (i) {
    }
})();
/*! 
 * vtexCommerceJs: https://doe.fundacaoedmilson.org.br/Scripts/vtex.tagmanager.helper.js
 */
vtexTagManagerHelper = function () {
    function n(n) {
        var t = this;
        t.eventType = n;
        t.data = {};
        t.sendEvent = function () {
            return vtex.events.sendEvent(t.eventType), !1
        };
        t.pageViewEvent = function () {
            var n = function (n) {
                vtex.events.addData(t.visitorData(n));
                t.processSubEvent()
            }, i = function () {
            };
            t.getProfile(n, i)
        };
        t.homeViewEvent = function () {
            return t.sendEvent()
        };
        t.productViewEvent = function () {
            return t.sendEvent()
        };
        t.departmentViewEvent = function () {
            return t.sendEvent()
        };
        t.categoryViewEvent = function () {
            return t.sendEvent()
        };
        t.internalSiteSearchView = function () {
            return t.sendEvent()
        }
    }

    return n.prototype.getProfile = function (n, t) {
        $.getJSON("/no-cache/profileSystem/getProfile").done(n).fail(t)
    }, n.prototype.visitorData = function (n) {
        return arguments.length === 0 ? this.data : (this.data.visitorLoginState = n.IsUserDefined, this.data.visitorExistingCustomer = n.IsUserDefined && n.UserId !== null, this.data.visitorType = n.IsReturningUser ? "returning user" : "new user", n.IsUserDefined && (this.data.visitorID = n.UserId, this.data.visitorContactInfo = [n.Email, n.FirstName, n.LastName], n.Gender !== null && (this.data.visitorDemographicInfo = {}, this.data.visitorDemographicInfo.gender = n.Gender)), this.data)
    }, n.prototype.processCurrentEvent = function () {
        var n = this;
        n.pageViewEvent()
    }, n.prototype.processSubEvent = function () {
        var n = this, t;
        return n.eventType ? (t = n[n.eventType + "Event"], typeof t == "function" ? t() : n.sendEvent()) : !1
    }, n.prototype.init = function (n) {
        var t = this;
        return vtex.events ? (t.processCurrentEvent(n), !1) : !1
    }, n
}()